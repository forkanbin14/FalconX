
import React, { useState, useEffect } from 'react';
import { UserRole, Course, User, Payment, Notification, Exam, ExamSubmission, ChatMessage, ActiveStatus, RecordedClass, PaymentRequest, Certificate } from './types';
import { MOCK_USERS, INITIAL_COURSES, INITIAL_CATEGORIES, MOCK_RECORDED_CLASSES } from './db/mockData';
import { Sidebar } from './components/Sidebar';
import { Navbar } from './components/Navbar';
import { StudentDashboard, TeacherDashboard } from './components/Dashboard';
import { CoursePlayer } from './components/CoursePlayer';
import { CreateCourse } from './components/CreateCourse';
import { AiTutorView } from './components/AiTutorView';
import { LiveClass } from './components/LiveClass';
import { Auth } from './components/Auth';
import { PaymentModal } from './components/PaymentModal';
import { GlassCard } from './components/GlassCard';
import { LiveExam } from './components/LiveExam';
import { ProfileView } from './components/ProfileView';
import { RecordedClasses } from './components/RecordedClasses';
import { CourseEditor } from './components/CourseEditor';
import { FalconxLogo } from './components/FalconxLogo';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [view, setView] = useState('dashboard');
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [activeLiveCourse, setActiveLiveCourse] = useState<Course | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  // Global States
  const [courses, setCourses] = useState<Course[]>(INITIAL_COURSES);
  const [users, setUsers] = useState<User[]>(MOCK_USERS);
  const [categories, setCategories] = useState<string[]>(INITIAL_CATEGORIES);
  const [recordings, setRecordings] = useState<RecordedClass[]>(MOCK_RECORDED_CLASSES);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [payoutRequests, setPayoutRequests] = useState<PaymentRequest[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [showPaymentModal, setShowPaymentModal] = useState<Course | null>(null);
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  
  // Exam States
  const [exams, setExams] = useState<Exam[]>([]);
  const [submissions, setSubmissions] = useState<ExamSubmission[]>([]);

  // Derived state for student access
  const enrolledCourseIds = payments
    .filter(p => p.userId === currentUser?.id && p.status === 'completed')
    .map(p => p.courseId);

  const addNotification = (notif: Omit<Notification, 'id' | 'isRead' | 'timestamp'>) => {
    const newNotif: Notification = {
      ...notif,
      id: Math.random().toString(36).substr(2, 9),
      isRead: false,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const approveEnrollment = (paymentId: string) => {
    const payment = payments.find(p => p.id === paymentId);
    if (!payment) return;

    setPayments(prev => prev.map(p => p.id === paymentId ? { ...p, status: 'completed' } : p));
    
    addNotification({
      userId: payment.userId,
      role: UserRole.STUDENT,
      title: 'Enrollment Verified',
      message: `Your access to "${payment.courseTitle}" has been authorized by the neural grid.`,
      type: 'success'
    });
  };

  const handleIssueCertificate = (courseId: string, studentId: string) => {
    const course = courses.find(c => c.id === courseId);
    const student = users.find(u => u.id === studentId);
    const teacher = users.find(u => u.id === currentUser?.id);

    if (!course || !student || !teacher) return;

    const exists = certificates.find(cert => cert.courseId === courseId && cert.studentId === studentId);
    if (exists) return alert("Certificate already issued for this node.");

    const newCert: Certificate = {
      id: 'CERT-' + Math.random().toString(36).substr(2, 6).toUpperCase(),
      courseId,
      courseTitle: course.title,
      studentId,
      studentName: student.name,
      instructorName: teacher.name,
      issueDate: new Date().toLocaleDateString(),
      hash: 'FX-' + Math.random().toString(36).substr(2, 10).toUpperCase()
    };

    setCertificates([...certificates, newCert]);
    
    addNotification({
      userId: studentId,
      role: UserRole.STUDENT,
      title: 'Certificate Awarded!',
      message: `Congratulations! You have been awarded a master certificate for "${course.title}".`,
      type: 'success'
    });

    alert(`Certificate generated for ${student.name}`);
  };

  const handlePaymentConfirm = (method: 'bkash' | 'nagad' | 'stripe', trxId: string) => {
    if (!showPaymentModal || !currentUser) return;

    const newPayment: Payment = {
      id: Math.random().toString(36).substr(2, 9),
      userId: currentUser.id,
      userName: currentUser.name,
      courseId: showPaymentModal.id,
      courseTitle: showPaymentModal.title,
      amount: showPaymentModal.price,
      method,
      status: method === 'stripe' ? 'completed' : 'pending',
      date: new Date().toISOString(),
      transactionId: trxId
    };

    setPayments(prev => [...prev, newPayment]);
    setShowPaymentModal(null);

    addNotification({
      userId: currentUser.id,
      role: UserRole.STUDENT,
      title: method === 'stripe' ? 'Enrollment Complete' : 'Verification Pending',
      message: method === 'stripe' 
        ? `Access to "${showPaymentModal.title}" granted immediately.`
        : `Transaction for "${showPaymentModal.title}" is being verified by admin nodes.`,
      type: 'success'
    });
  };

  const handleLogin = (user: User) => {
    setIsLoggingIn(true);
    const existingUser = users.find(u => u.email === user.email);
    
    setTimeout(() => {
      setCurrentUser(existingUser || user);
      const targetUser = existingUser || user;
      if (targetUser.role === UserRole.STUDENT) setView('dashboard');
      else if (targetUser.role === UserRole.TEACHER) setView('teacher-dashboard');
      else setView('admin-dashboard');
      
      setTimeout(() => setIsLoggingIn(false), 2500);
    }, 1200);
  };

  const handleUpdateCourse = (updated: Course) => {
    setCourses(courses.map(c => c.id === updated.id ? updated : c));
    setEditingCourse(null);
    addNotification({
      userId: currentUser?.id || '',
      role: UserRole.TEACHER,
      title: 'Course Assets Updated',
      message: `Modifications for "${updated.title}" synced successfully.`,
      type: 'success'
    });
  };

  const startTeacherLive = (course: Course) => {
    setActiveLiveCourse(course);
    setView('live-studio');
  };

  const renderContent = () => {
    if (!currentUser) return null;

    if (selectedCourse) {
      return (
        <CoursePlayer 
          course={selectedCourse} 
          onBack={() => setSelectedCourse(null)} 
          userRole={currentUser.role} 
          userName={currentUser.name} 
          recordings={recordings.filter(r => r.courseId === selectedCourse.id)}
          isEnrolled={enrolledCourseIds.includes(selectedCourse.id)}
          certificate={certificates.find(cert => cert.courseId === selectedCourse.id && cert.studentId === currentUser.id)}
        />
      );
    }

    if (editingCourse) {
      return <CourseEditor course={editingCourse} categories={categories} onSave={handleUpdateCourse} onCancel={() => setEditingCourse(null)} onGoLive={startTeacherLive} />;
    }

    switch (view) {
      case 'dashboard':
      case 'browse':
        if (currentUser.role === UserRole.TEACHER) {
          return <TeacherDashboard 
            user={users.find(u => u.id === currentUser.id) || currentUser} 
            courses={courses.filter(c => c.instructorId === currentUser.id)} 
            revenueHistory={[]}
            onEditCourse={(c) => setEditingCourse(c)} 
            onGoLive={startTeacherLive}
            onViewInsights={() => {}} 
            onRequestPayout={() => {}}
            onCreateCourse={() => setView('create-course')}
            payments={payments}
            onIssueCertificate={handleIssueCertificate}
          />;
        }
        return <StudentDashboard 
          courses={courses} 
          categories={categories} 
          onCourseSelect={(c) => {
            const isEnrolled = enrolledCourseIds.includes(c.id);
            if (isEnrolled) setSelectedCourse(c);
            else setShowPaymentModal(c);
          }} 
          enrolledIds={enrolledCourseIds} 
          pendingIds={payments.filter(p => p.userId === currentUser.id && p.status === 'pending').map(p => p.courseId)} 
        />;
      case 'teacher-dashboard':
        return <TeacherDashboard 
          user={users.find(u => u.id === currentUser.id) || currentUser} 
          courses={courses.filter(c => c.instructorId === currentUser.id)} 
          revenueHistory={[]}
          onEditCourse={(c) => setEditingCourse(c)} 
          onGoLive={startTeacherLive}
          onViewInsights={() => {}} 
          onRequestPayout={() => {}}
          onCreateCourse={() => setView('create-course')}
          payments={payments}
          onIssueCertificate={handleIssueCertificate}
        />;
      case 'live-classes':
        if (currentUser.role === UserRole.TEACHER) {
          const teacherCourses = courses.filter(c => c.instructorId === currentUser.id);
          return (
            <div className="space-y-10 animate-fade-up">
              <header>
                <h2 className="text-4xl font-black text-white tracking-tighter">Live <span className="text-indigo-500">Node Switch</span></h2>
                <p className="text-white/40 font-medium">Select a module to initiate a real-time broadcast session.</p>
              </header>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {teacherCourses.map(course => (
                  <GlassCard key={course.id} className="p-0 overflow-hidden group border-white/5 hover:border-red-500/30">
                    <div className="relative h-40">
                      <img src={course.thumbnail} className="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-opacity" />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#0f172a] to-transparent"></div>
                      <div className="absolute bottom-4 left-4">
                        <span className="text-[8px] font-black uppercase tracking-widest bg-red-500 text-white px-2 py-1 rounded">Ecosystem Module</span>
                      </div>
                    </div>
                    <div className="p-6">
                      <h4 className="text-lg font-bold text-white mb-6 truncate">{course.title}</h4>
                      <button 
                        onClick={() => startTeacherLive(course)}
                        className="w-full py-3.5 rounded-xl bg-red-500 text-white text-[10px] font-black uppercase tracking-widest shadow-lg shadow-red-500/20 hover:scale-[1.02] transition-all flex items-center justify-center gap-2"
                      >
                        <span className="w-2 h-2 rounded-full bg-white animate-pulse"></span>
                        Engage Studio
                      </button>
                    </div>
                  </GlassCard>
                ))}
              </div>
            </div>
          );
        } else if (currentUser.role === UserRole.STUDENT) {
          const enrolledCourses = courses.filter(c => enrolledCourseIds.includes(c.id));
          return (
            <div className="space-y-10 animate-fade-up">
              <header>
                <h2 className="text-4xl font-black text-white tracking-tighter">Active <span className="text-indigo-500">Transmissions</span></h2>
                <p className="text-white/40 font-medium">Direct access to live sessions for your enrolled modules.</p>
              </header>
              {enrolledCourses.length === 0 ? (
                <div className="p-20 text-center glass rounded-[2.5rem] border-dashed border-2 border-white/5 opacity-40">
                  <p className="text-xs font-black uppercase tracking-widest leading-loose">No verified modules found.<br/>Enroll in a course to access live broadcasts.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {enrolledCourses.map(course => {
                    const isActive = course.liveSchedules?.some(s => s.isActive);
                    return (
                      <GlassCard key={course.id} className={`p-0 overflow-hidden group border-white/5 transition-all ${isActive ? 'ring-2 ring-red-500/30 bg-red-500/[0.02]' : ''}`}>
                        <div className="relative h-44">
                          <img src={course.thumbnail} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60"></div>
                          {isActive && (
                            <div className="absolute top-4 left-4">
                              <span className="bg-red-500 text-white text-[8px] font-black uppercase tracking-widest px-2 py-1 rounded shadow-lg animate-pulse">Live Now</span>
                            </div>
                          )}
                        </div>
                        <div className="p-6">
                          <h4 className="font-bold text-white mb-6 truncate">{course.title}</h4>
                          <button 
                            onClick={() => setSelectedCourse(course)}
                            className={`w-full py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                              isActive 
                              ? 'bg-red-500 text-white shadow-xl shadow-red-500/20 animate-bounce-subtle' 
                              : 'bg-white/5 text-white/40 border border-white/5 hover:bg-white/10 hover:text-white'
                            }`}
                          >
                            {isActive ? 'Enter Live Broadcast' : 'View Module Schedule'}
                          </button>
                        </div>
                      </GlassCard>
                    );
                  })}
                </div>
              )}
            </div>
          );
        }
        return <div className="text-white/20 p-20 text-center italic">Session module loading...</div>;
      case 'live-studio':
        return (
          <div className="space-y-8 h-full">
            <button onClick={() => setView('teacher-dashboard')} className="text-white/40 hover:text-white text-xs font-black uppercase tracking-widest flex items-center gap-2 group">
              <span className="group-hover:-translate-x-1 transition-transform">←</span> Exit Studio
            </button>
            <LiveClass 
              role={currentUser.role} 
              userName={currentUser.name} 
              courseTitle={activeLiveCourse?.title || "Masterclass"}
            />
          </div>
        );
      case 'create-course':
        return <CreateCourse categories={categories} currentUser={currentUser} onPublish={(c) => { setCourses([...courses, c]); setView('teacher-dashboard'); }} />;
      case 'recorded-classes':
        return <RecordedClasses recordings={recordings} />;
      case 'live-exams':
        const filteredExams = currentUser.role === UserRole.STUDENT 
          ? exams.filter(e => enrolledCourseIds.includes(e.courseId))
          : exams.filter(e => courses.find(c => c.id === e.courseId)?.instructorId === currentUser.id);

        return <LiveExam 
          role={currentUser.role} 
          user={currentUser} 
          exams={filteredExams} 
          submissions={submissions} 
          onAddExam={(e) => setExams([e, ...exams])} 
          onUpdateExam={(u) => setExams(exams.map(e => e.id === u.id ? u : e))} 
          onFinalizeResults={(id) => {
            const sorted = [...submissions.filter(s => s.examId === id)].sort((a, b) => b.score - a.score);
            setSubmissions(submissions.map(s => s.examId === id ? { ...s, rank: sorted.findIndex(sub => sub.id === s.id) + 1 } : s));
          }} 
          onSubmitExam={(s) => setSubmissions([s, ...submissions])} 
          teacherCourses={courses.filter(c => c.instructorId === currentUser.id)}
        />;
      case 'tutor':
        return <AiTutorView />;
      case 'profile':
        return <ProfileView user={currentUser} onUpdate={setCurrentUser} />;
      case 'admin-dashboard':
        return (
          <div className="space-y-12">
            <h2 className="text-4xl font-black text-white">System <span className="text-indigo-500">Node Hub</span></h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
              <section className="space-y-6">
                <h3 className="text-xl font-bold text-white">Enrollment Queue</h3>
                {payments.filter(p => p.status === 'pending').map(p => (
                  <GlassCard key={p.id} className="flex justify-between items-center border-white/5">
                    <div>
                      <p className="font-extrabold text-white">{p.userName}</p>
                      <p className="text-xs text-white/40">{p.courseTitle}</p>
                    </div>
                    <button onClick={() => approveEnrollment(p.id)} className="btn-gradient px-6 py-2 rounded-xl text-xs font-black uppercase text-white">Approve</button>
                  </GlassCard>
                ))}
              </section>
            </div>
          </div>
        );
      default:
        return <div className="text-white/20 italic p-20 text-center">Section under development in neural engine.</div>;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[#0f172a]">
      {isLoggingIn && (
        <div className="fixed inset-0 z-[1000] flex flex-col items-center justify-center bg-[#060812] overflow-hidden">
          <div className="absolute inset-0 opacity-40">
             <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-indigo-600/30 blur-[120px] rounded-full"></div>
             <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-teal-500/20 blur-[120px] rounded-full"></div>
          </div>
          <div className="relative z-10 flex flex-col items-center animate-spring-up">
            <FalconxLogo animate={true} className="w-72 h-72" />
            <div className="mt-12 flex flex-col items-center gap-6">
              <div className="h-1 w-64 bg-white/5 rounded-full overflow-hidden relative">
                <div className="h-full bg-indigo-500 shadow-[0_0_15px_rgba(99,102,241,0.8)] animate-[loading_2.5s_ease-in-out_infinite]"></div>
              </div>
              <div className="flex flex-col items-center">
                 <p className="text-[12px] font-black text-white/40 uppercase tracking-[0.6em]">System Initializing</p>
                 <p className="text-[9px] font-bold text-indigo-400 uppercase tracking-[0.2em] mt-2 italic">Neural nodes connecting...</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {currentUser && !isLoggingIn && (
        <>
          <Sidebar role={currentUser.role} currentView={view} setView={setView} isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} onLogout={() => setCurrentUser(null)} />
          <div className="flex-1 flex flex-col min-w-0">
            <Navbar onMenuClick={() => setIsSidebarOpen(true)} userName={currentUser.name} notifications={notifications.filter(n => n.userId === currentUser.id || n.role === currentUser.role || n.role === 'ALL')} onMarkRead={() => {}} currentStatus={currentUser.activeStatus || 'online'} onStatusChange={() => {}} />
            <main className="flex-1 overflow-y-auto p-6 lg:p-12 relative scroll-smooth custom-scrollbar">
              <div className="max-w-7xl mx-auto pb-20">{renderContent()}</div>
            </main>
          </div>
        </>
      )}
      {!currentUser && !isLoggingIn && <Auth onLogin={handleLogin} />}
      {showPaymentModal && <PaymentModal course={showPaymentModal} onClose={() => setShowPaymentModal(null)} onConfirm={handlePaymentConfirm} />}
      <style>{`
        @keyframes bounce-subtle {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-4px); }
        }
        .animate-bounce-subtle {
          animation: bounce-subtle 2s infinite ease-in-out;
        }
      `}</style>
    </div>
  );
};

export default App;
