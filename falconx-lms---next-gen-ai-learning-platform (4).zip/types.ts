
export enum UserRole {
  STUDENT = 'STUDENT',
  TEACHER = 'TEACHER',
  ADMIN = 'ADMIN'
}

export type Difficulty = 'Basic' | 'Intermediate' | 'Advanced';
export type ActiveStatus = 'online' | 'away' | 'busy' | 'offline';

export type PaymentRequestStatus = 'requested' | 'approved' | 'completed' | 'rejected';

export interface LiveSchedule {
  id: string;
  topic: string;
  startTime: string; // ISO string
  duration: string;
  isActive: boolean;
  isCompleted: boolean;
}

export interface Certificate {
  id: string;
  courseId: string;
  courseTitle: string;
  studentId: string;
  studentName: string;
  instructorName: string;
  issueDate: string;
  hash: string; // Unique verification hash
}

export interface PaymentRequest {
  id: string;
  teacherId: string;
  teacherName: string;
  amount: number;       // Gross amount requested
  taxAmount: number;    // 5% tax
  netAmount: number;    // 95% to be paid
  status: PaymentRequestStatus;
  requestedAt: string;
  method: string;
  accountDetails: string;
}

export interface UserProfile {
  bio?: string;
  coverPic?: string;
  currentCity?: string;
  division?: string;
  phone?: string;
  age?: number;
  gender?: 'Male' | 'Female' | 'Other';
  educationLevel?: string;
  subject?: string;
  experience?: string;
  expertiseSubject?: string;
  currentInstituteSubject?: string;
  mentorshipSubject?: string;
  institute?: string;
}

export interface User {
  id: string;
  uniqueCode: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  activeStatus?: ActiveStatus;
  profile?: UserProfile;
  isVerified?: boolean;
  walletBalance?: number; 
}

export interface ChatMessage {
  id: string;
  senderId: string;
  receiverId: string;
  text: string;
  timestamp: string;
}

export interface Material {
  id: string;
  title: string;
  url: string;
  type: 'pdf' | 'zip' | 'link' | 'image' | 'video';
}

export interface Lesson {
  id: string;
  title: string;
  content: string;
  videoUrl?: string;
  pdfUrl?: string;
  materials?: Material[];
}

export interface MCQ {
  question: string;
  options: string[];
  answer: string;
  explanation: string;
}

export interface QuizGenerationResult {
  mcq: MCQ[];
  short: string[];
  suggestions: string;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  coverImage?: string;
  instructorId: string;
  price: number;
  isApproved: boolean;
  status: 'draft' | 'published';
  lessons: Lesson[];
  quizzes: any[];
  category: string;
  liveSchedules?: LiveSchedule[];
}

export interface Payment {
  id: string;
  userId: string;
  userName: string;
  courseId: string;
  courseTitle: string;
  amount: number;
  method: 'bkash' | 'nagad' | 'stripe';
  status: 'pending' | 'completed' | 'rejected';
  date: string;
  transactionId: string;
}

export interface Notification {
  id: string;
  userId: string;
  role: UserRole | 'ALL';
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  isRead: boolean;
  timestamp: string;
}

export interface RecordedClass {
  id: string;
  title: string;
  courseId: string;
  instructorName: string;
  videoUrl: string;
  slidesUrl: string;
  duration: string;
  date: string;
  thumbnail: string;
}

export interface ExamQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
}

export interface Exam {
  id: string;
  courseId: string;
  title: string;
  durationMinutes: number;
  status: 'draft' | 'active' | 'completed';
  questions: ExamQuestion[];
}

export interface ExamSubmission {
  id: string;
  examId: string;
  userId: string;
  userName: string;
  score: number;
  totalQuestions: number;
  answers: number[];
  timestamp: string;
  rank?: number;
}
