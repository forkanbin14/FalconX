
import React, { useState, useRef, useEffect } from 'react';
import { UserRole } from '../types';
import { GlassCard } from './GlassCard';

interface FloatingReaction {
  id: number;
  emoji: string;
  left: number;
}

interface Participant {
  id: string;
  name: string;
  active: boolean;
  isBlocked: boolean;
}

interface LiveClassProps {
  role: UserRole;
  userName: string;
  courseTitle?: string;
  onShare?: (classTitle: string) => void;
}

export const LiveClass: React.FC<LiveClassProps> = ({ role, userName, courseTitle = "Live Masterclass", onShare }) => {
  const [isLive, setIsLive] = useState(false);
  const [participants, setParticipants] = useState<Participant[]>([
    { id: 'ps1', name: 'Alice Smith', active: true, isBlocked: false },
    { id: 'ps2', name: 'Bob Jones', active: true, isBlocked: false },
    { id: 'ps3', name: 'Charlie Davis', active: false, isBlocked: false },
    { id: 'ps4', name: 'Diana Prince', active: true, isBlocked: false },
  ]);
  const [chatMessages, setChatMessages] = useState([
    { user: 'Alice Smith', text: 'Excited for today\'s session!', time: '10:02 AM' },
    { user: 'Bob Jones', text: 'Can you explain the last module again?', time: '10:05 AM' },
  ]);
  const [chatInput, setChatInput] = useState('');
  const [floatingReactions, setFloatingReactions] = useState<FloatingReaction[]>([]);
  const [isUserBlocked, setIsUserBlocked] = useState(false); 
  const videoRef = useRef<HTMLVideoElement>(null);

  const toggleLive = async () => {
    if (isLive) {
      const stream = videoRef.current?.srcObject as MediaStream;
      stream?.getTracks().forEach(track => track.stop());
      setIsLive(false);
    } else {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        if (videoRef.current) videoRef.current.srcObject = stream;
        setIsLive(true);
      } catch (err) {
        alert("Camera access denied or not available.");
      }
    }
  };

  const handleSendMessage = () => {
    if (!chatInput.trim() || isUserBlocked) return;
    setChatMessages([...chatMessages, { user: userName, text: chatInput, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
    setChatInput('');
  };

  const handleBlockStudent = (id: string) => {
    setParticipants(prev => prev.map(p => p.id === id ? { ...p, isBlocked: !p.isBlocked } : p));
  };

  const triggerReaction = (emoji: string) => {
    if (isUserBlocked) return;
    const newReaction: FloatingReaction = {
      id: Date.now(),
      emoji,
      left: Math.random() * 80 + 10,
    };
    setFloatingReactions(prev => [...prev, newReaction]);
    setTimeout(() => {
      setFloatingReactions(prev => prev.filter(r => r.id !== newReaction.id));
    }, 3000);
  };

  const renderTeacherView = () => (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-full animate-fade-up">
      <div className="lg:col-span-8 flex flex-col gap-6">
        <GlassCard className="relative p-0 overflow-hidden bg-black aspect-video flex items-center justify-center border-white/10 shadow-2xl rounded-[2.5rem]">
          <video 
            ref={videoRef} 
            autoPlay 
            muted 
            playsInline 
            className={`w-full h-full object-cover transition-opacity duration-700 ${isLive ? 'opacity-100' : 'opacity-0'}`} 
          />
          
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            {floatingReactions.map(r => (
              <span 
                key={r.id} 
                className="absolute bottom-0 text-4xl animate-float-up"
                style={{ left: `${r.left}%` }}
              >
                {r.emoji}
              </span>
            ))}
          </div>

          {!isLive && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-6 text-center p-12">
              <div className="w-24 h-24 rounded-full bg-indigo-500/10 flex items-center justify-center animate-pulse">
                <span className="text-5xl">🎥</span>
              </div>
              <div>
                <h3 className="text-2xl font-black text-white mb-2">Studio Hub: {courseTitle}</h3>
                <p className="text-white/40 max-w-sm">Synchronize your node to begin the live ecosystem broadcast.</p>
              </div>
            </div>
          )}
          
          {isLive && (
            <div className="absolute top-8 left-8 flex items-center gap-3">
              <div className="bg-red-500 px-4 py-1.5 rounded-xl flex items-center gap-2 shadow-lg animate-pulse">
                <span className="w-2 h-2 rounded-full bg-white"></span>
                <span className="text-[10px] font-black uppercase tracking-widest text-white">Broadcasting</span>
              </div>
              <div className="bg-black/60 backdrop-blur-md px-4 py-1.5 rounded-xl text-[10px] font-bold text-white border border-white/10 uppercase tracking-widest">
                {courseTitle}
              </div>
            </div>
          )}
        </GlassCard>

        <div className="flex items-center justify-between gap-4">
          <button 
            onClick={toggleLive}
            className={`flex-1 py-4 rounded-2xl font-black uppercase tracking-widest transition-all ${
              isLive ? 'bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500 hover:text-white' : 'btn-gradient text-white'
            }`}
          >
            {isLive ? 'Cease Broadcast' : 'Engage Neural Link'}
          </button>
          <div className="flex gap-2">
            <button className="p-4 rounded-2xl glass text-white hover:bg-white/10 shadow-lg">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"/></svg>
            </button>
            <button className="p-4 rounded-2xl glass text-white hover:bg-white/10 shadow-lg">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
            </button>
          </div>
        </div>
      </div>

      <div className="lg:col-span-4 flex flex-col gap-6">
        <GlassCard className="flex-1 flex flex-col p-0 overflow-hidden border-white/5 bg-slate-900/40">
          <div className="p-6 border-b border-white/5 flex items-center justify-between bg-indigo-500/5">
            <h4 className="font-black text-xs uppercase tracking-widest text-indigo-400">Class Matrix Chat</h4>
            <span className="text-[10px] bg-white/5 px-2 py-1 rounded-md text-white/40 font-bold">42 Nodes</span>
          </div>
          <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
            {chatMessages.map((msg, i) => (
              <div key={i} className="animate-fade-up">
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-xs font-black text-white">{msg.user}</span>
                  <span className="text-[8px] font-bold text-white/20 uppercase">{msg.time}</span>
                </div>
                <div className="bg-white/5 p-3 rounded-2xl rounded-tl-none border border-white/5">
                  <p className="text-sm text-white/60 leading-relaxed font-medium">{msg.text}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="p-6 border-t border-white/5 bg-black/20">
            <div className="flex gap-2">
              <input 
                value={chatInput}
                onChange={e => setChatInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
                placeholder="Broadcast to participants..."
                className="flex-1 bg-white/5 border border-white/10 rounded-2xl px-5 py-3.5 text-xs text-white focus:outline-none focus:border-indigo-500 transition-all font-medium"
              />
              <button onClick={handleSendMessage} className="p-3 bg-indigo-500 rounded-xl text-white shadow-xl hover:scale-105 transition-transform">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z"/></svg>
              </button>
            </div>
          </div>
        </GlassCard>

        <GlassCard className="h-64 flex flex-col p-0 overflow-hidden border-white/5">
           <div className="p-5 border-b border-white/5 bg-white/5">
              <h4 className="font-black text-[10px] uppercase tracking-widest text-white/40">Moderation Hub</h4>
           </div>
           <div className="flex-1 overflow-y-auto p-2 space-y-1 custom-scrollbar">
              {participants.map((p, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-2xl hover:bg-white/5 transition-all group">
                   <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl ${p.isBlocked ? 'bg-red-500/20 text-red-400' : 'bg-indigo-500/20 text-indigo-300'} flex items-center justify-center text-xs font-black border border-white/5`}>
                         {p.name.charAt(0)}
                      </div>
                      <div className="flex flex-col">
                        <span className={`text-sm font-bold ${p.isBlocked ? 'text-red-400 line-through' : 'text-white/70'} group-hover:text-white`}>{p.name}</span>
                        {p.isBlocked && <span className="text-[7px] text-red-500 font-black uppercase tracking-widest">Neural Link Severed</span>}
                      </div>
                   </div>
                   <button 
                      onClick={() => handleBlockStudent(p.id)}
                      className={`p-2 rounded-xl transition-all ${p.isBlocked ? 'bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500 hover:text-white' : 'bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white'}`}
                   >
                     {p.isBlocked ? '🔓' : '🚫'}
                   </button>
                </div>
              ))}
           </div>
        </GlassCard>
      </div>
    </div>
  );

  const renderStudentView = () => (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-full animate-fade-up">
      <div className="lg:col-span-8 space-y-6">
        <div className="relative group">
          <GlassCard className="relative p-0 overflow-hidden bg-slate-900 aspect-video flex items-center justify-center border-white/10 shadow-2xl rounded-[2.5rem]">
            <img 
              src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=1200" 
              className="w-full h-full object-cover opacity-60 grayscale hover:grayscale-0 transition-all duration-1000"
              alt="Live Stream"
            />
            
            <div className="absolute inset-0 pointer-events-none overflow-hidden">
              {floatingReactions.map(r => (
                <span 
                  key={r.id} 
                  className="absolute bottom-0 text-4xl animate-float-up"
                  style={{ left: `${r.left}%` }}
                >
                  {r.emoji}
                </span>
              ))}
            </div>

            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
            
            <div className="absolute top-8 left-8 flex items-center gap-3">
              <div className="bg-emerald-500 px-4 py-1.5 rounded-xl flex items-center gap-2 shadow-lg">
                <span className="w-2 h-2 rounded-full bg-white animate-pulse"></span>
                <span className="text-[10px] font-black uppercase tracking-widest text-white">Live Synchrony</span>
              </div>
              <div className="bg-black/40 backdrop-blur-md px-4 py-1.5 rounded-xl text-[10px] font-bold text-white border border-white/10 uppercase tracking-widest">
                {courseTitle}
              </div>
            </div>

            {isUserBlocked ? (
              <div className="absolute inset-0 z-50 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center text-center p-12">
                 <span className="text-6xl mb-6">🚫</span>
                 <h2 className="text-2xl font-black text-white mb-2 uppercase tracking-tighter">Identity Blocked</h2>
                 <p className="text-white/40 text-sm max-w-xs font-medium">An instructor has suspended your transmission privileges in this ecosystem.</p>
              </div>
            ) : (
              <div className="absolute bottom-16 flex flex-col items-center justify-center text-center w-full px-12">
                <div className="w-20 h-20 rounded-full glass flex items-center justify-center mb-6 border-white/20 hover:scale-110 transition-transform cursor-pointer shadow-2xl">
                    <svg className="w-10 h-10 text-white ml-1.5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                </div>
                <h3 className="text-2xl font-black text-white tracking-tight shadow-sm">Syncing Stream Pipeline...</h3>
              </div>
            )}
          </GlassCard>

          {!isUserBlocked && (
            <div className="absolute bottom-6 right-6 flex flex-col gap-2 p-2 glass rounded-[1.5rem] border-white/10 opacity-0 group-hover:opacity-100 transition-opacity shadow-2xl">
               {['👍', '❤️', '🔥', '👏', '😮'].map(emoji => (
                 <button 
                  key={emoji}
                  onClick={() => triggerReaction(emoji)}
                  className="w-11 h-11 flex items-center justify-center bg-white/5 hover:bg-white/10 rounded-xl transition-all hover:scale-125 active:scale-95"
                 >
                   <span className="text-2xl">{emoji}</span>
                 </button>
               ))}
            </div>
          )}
        </div>

        <GlassCard className="p-10 border-white/5 bg-white/[0.02]">
           <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 mb-8">
              <div>
                <h3 className="text-3xl font-black text-white mb-2 tracking-tighter">{courseTitle}</h3>
                <p className="text-indigo-400 font-bold text-xs uppercase tracking-[0.2em]">Active Ecosystem Session • Neural Verified</p>
              </div>
              <button 
                onClick={() => onShare && onShare(courseTitle)}
                className="btn-gradient px-10 py-4 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] text-white flex items-center justify-center gap-3 shadow-2xl hover:scale-105 transition-all"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"/></svg>
                Sync with Network
              </button>
           </div>
           
           <p className="text-white/40 text-lg leading-relaxed mb-8 font-medium">Engage with this live masterclass module. Use the chat to pose queries to the instructor in real-time. Adaptive synthesis is active.</p>
           
           <div className="flex items-center gap-8 pt-8 border-t border-white/5">
              <div className="flex items-center gap-4">
                 <div className="w-12 h-12 rounded-[1.2rem] bg-indigo-500 p-0.5 shadow-xl">
                    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Teacher" className="rounded-[1rem]" />
                 </div>
                 <div>
                    <p className="text-sm font-black text-white">System Instructor</p>
                    <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest">Ecosystem Lead</p>
                 </div>
              </div>
           </div>
        </GlassCard>
      </div>

      <div className="lg:col-span-4 flex flex-col gap-6">
         <GlassCard className="flex-1 flex flex-col p-0 overflow-hidden border-white/5 bg-slate-900/40 shadow-2xl">
          <div className="p-6 border-b border-white/5 flex items-center justify-between bg-indigo-500/5">
            <h4 className="font-black text-xs uppercase tracking-widest text-indigo-400">Class Matrix Chat</h4>
          </div>
          <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
            {chatMessages.map((msg, i) => (
              <div key={i} className="animate-fade-up">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs font-black text-white">{msg.user}</span>
                  <span className="text-[9px] font-bold text-white/20 uppercase">{msg.time}</span>
                </div>
                <div className="glass p-4 rounded-2xl rounded-tl-none border-white/5 bg-white/5">
                  <p className="text-sm text-white/80 leading-relaxed font-medium">{msg.text}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="p-8 border-t border-white/5 bg-slate-950/60 backdrop-blur-3xl">
            {isUserBlocked ? (
              <div className="text-center p-4 rounded-2xl bg-red-500/10 border border-red-500/20 shadow-inner">
                <p className="text-[10px] font-black text-red-400 uppercase tracking-widest">Ecosystem Link Severed</p>
              </div>
            ) : (
              <div className="relative">
                <input 
                  value={chatInput}
                  onChange={e => setChatInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Ask a query to the node..."
                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-sm text-white focus:outline-none focus:border-indigo-500 transition-all font-medium placeholder:text-white/20"
                />
                <button onClick={handleSendMessage} className="absolute right-3.5 top-1/2 -translate-y-1/2 p-2.5 bg-indigo-500 rounded-xl text-white shadow-xl shadow-indigo-500/20 hover:scale-110 transition-transform">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z"/></svg>
                </button>
              </div>
            )}
          </div>
        </GlassCard>
      </div>

      <style>{`
        @keyframes floatUp {
          0% { transform: translateY(0) scale(1); opacity: 0; }
          10% { opacity: 1; }
          100% { transform: translateY(-300px) scale(1.5); opacity: 0; }
        }
        .animate-float-up {
          animation: floatUp 3s ease-out forwards;
        }
      `}</style>
    </div>
  );

  return (
    <div className="h-full">
      {role === UserRole.TEACHER ? renderTeacherView() : renderStudentView()}
    </div>
  );
};
