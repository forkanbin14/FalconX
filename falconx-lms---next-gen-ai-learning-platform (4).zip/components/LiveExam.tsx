
import React, { useState, useEffect } from 'react';
import { UserRole, Exam, ExamSubmission, ExamQuestion, User, Course } from '../types';
import { GlassCard } from './GlassCard';

interface LiveExamProps {
  role: UserRole;
  user: User;
  exams: Exam[];
  submissions: ExamSubmission[];
  onAddExam: (exam: Exam) => void;
  onUpdateExam: (exam: Exam) => void;
  onFinalizeResults: (examId: string) => void;
  onSubmitExam: (submission: ExamSubmission) => void;
  teacherCourses?: Course[];
}

export const LiveExam: React.FC<LiveExamProps> = ({ 
  role, 
  user, 
  exams, 
  submissions, 
  onAddExam, 
  onUpdateExam,
  onFinalizeResults,
  onSubmitExam,
  teacherCourses = []
}) => {
  const [activeExam, setActiveExam] = useState<Exam | null>(null);
  const [examState, setExamState] = useState<{ currentQuestion: number; answers: number[]; timeLeft: number } | null>(null);
  const [editingExam, setEditingExam] = useState<Partial<Exam> | null>(null);

  // --- Student Logic ---
  const startExam = (exam: Exam) => {
    setActiveExam(exam);
    setExamState({
      currentQuestion: 0,
      answers: new Array(exam.questions.length).fill(-1),
      timeLeft: exam.durationMinutes * 60
    });
  };

  useEffect(() => {
    let timer: any;
    if (examState && examState.timeLeft > 0) {
      timer = setInterval(() => {
        setExamState(prev => prev ? { ...prev, timeLeft: prev.timeLeft - 1 } : null);
      }, 1000);
    } else if (examState && examState.timeLeft === 0) {
      handleExamFinish();
    }
    return () => clearInterval(timer);
  }, [examState]);

  const handleExamFinish = () => {
    if (!activeExam || !examState) return;
    
    let score = 0;
    activeExam.questions.forEach((q, i) => {
      if (examState.answers[i] === q.correctAnswer) score++;
    });

    onSubmitExam({
      id: Math.random().toString(36).substr(2, 9),
      examId: activeExam.id,
      userId: user.id,
      userName: user.name,
      score: score,
      totalQuestions: activeExam.questions.length,
      answers: examState.answers,
      timestamp: new Date().toISOString()
    });
    
    setActiveExam(null);
    setExamState(null);
  };

  // --- Teacher Logic ---
  const handleOpenCreate = () => {
    setEditingExam({
      title: '',
      courseId: teacherCourses[0]?.id || '',
      durationMinutes: 30,
      status: 'active',
      questions: [{ id: 'q1', question: '', options: ['', '', '', ''], correctAnswer: 0 }]
    });
  };

  const handleEditExam = (exam: Exam) => {
    setEditingExam({ ...exam });
  };

  const handleSaveExam = () => {
    if (!editingExam?.title || !editingExam?.questions?.length || !editingExam?.courseId) {
      alert("Please fill in the title, associated course, and at least one question.");
      return;
    }

    const examData = {
      ...editingExam,
      id: editingExam.id || 'ex-' + Math.random().toString(36).substr(2, 5),
    } as Exam;

    if (editingExam.id) {
      onUpdateExam(examData);
    } else {
      onAddExam(examData);
    }
    setEditingExam(null);
  };

  const addQuestion = () => {
    if (!editingExam) return;
    const newQ: ExamQuestion = {
      id: 'q' + (editingExam.questions!.length + 1),
      question: '',
      options: ['', '', '', ''],
      correctAnswer: 0
    };
    setEditingExam({ ...editingExam, questions: [...editingExam.questions!, newQ] });
  };

  const updateQuestion = (index: number, field: string, value: any) => {
    if (!editingExam) return;
    const qs = [...editingExam.questions!];
    qs[index] = { ...qs[index], [field]: value };
    setEditingExam({ ...editingExam, questions: qs });
  };

  const updateOption = (qIndex: number, oIndex: number, value: string) => {
    if (!editingExam) return;
    const qs = [...editingExam.questions!];
    const opts = [...qs[qIndex].options];
    opts[oIndex] = value;
    qs[qIndex] = { ...qs[qIndex], options: opts };
    setEditingExam({ ...editingExam, questions: qs });
  };

  const removeQuestion = (index: number) => {
    if (!editingExam || editingExam.questions!.length <= 1) return;
    const qs = editingExam.questions!.filter((_, i) => i !== index);
    setEditingExam({ ...editingExam, questions: qs });
  };

  const renderStudentView = () => {
    if (activeExam && examState) {
      const q = activeExam.questions[examState.currentQuestion];
      return (
        <div className="max-w-4xl mx-auto space-y-8 animate-fade-up">
          <header className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-black text-white">{activeExam.title}</h2>
              <p className="text-indigo-400 font-bold uppercase text-xs tracking-widest mt-1">Live MCQ Assessment</p>
            </div>
            <div className="glass px-6 py-3 rounded-2xl flex items-center gap-4">
               <span className="text-white/40 font-bold text-xs uppercase">Time Remaining</span>
               <span className={`text-xl font-black ${examState.timeLeft < 60 ? 'text-red-500 animate-pulse' : 'text-white'}`}>
                 {Math.floor(examState.timeLeft / 60)}:{(examState.timeLeft % 60).toString().padStart(2, '0')}
               </span>
            </div>
          </header>

          <GlassCard className="p-10">
            <div className="mb-8 flex items-center justify-between">
              <span className="text-indigo-400 font-black text-xs uppercase tracking-widest">Question {examState.currentQuestion + 1} of {activeExam.questions.length}</span>
              <div className="flex gap-2">
                {activeExam.questions.map((_, i) => (
                  <div key={i} className={`w-2 h-2 rounded-full ${i === examState.currentQuestion ? 'bg-indigo-500' : examState.answers[i] !== -1 ? 'bg-indigo-500/40' : 'bg-white/10'}`}></div>
                ))}
              </div>
            </div>

            <h3 className="text-2xl font-bold text-white mb-8">{q.question}</h3>
            
            <div className="space-y-4">
              {q.options.map((opt, i) => (
                <button
                  key={i}
                  onClick={() => {
                    const newAnswers = [...examState.answers];
                    newAnswers[examState.currentQuestion] = i;
                    setExamState({ ...examState, answers: newAnswers });
                  }}
                  className={`w-full text-left p-6 rounded-2xl border transition-all flex items-center justify-between group ${
                    examState.answers[examState.currentQuestion] === i 
                    ? 'border-indigo-500 bg-indigo-500/10 text-white shadow-[0_0_30px_rgba(99,102,241,0.2)]' 
                    : 'border-white/5 bg-white/5 text-white/60 hover:bg-white/10'
                  }`}
                >
                  <span className="font-semibold">{opt || `Option ${i+1}`}</span>
                  <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                    examState.answers[examState.currentQuestion] === i ? 'border-indigo-500 bg-indigo-500' : 'border-white/10'
                  }`}>
                    {examState.answers[examState.currentQuestion] === i && <div className="w-2 h-2 bg-white rounded-full"></div>}
                  </div>
                </button>
              ))}
            </div>

            <div className="mt-12 flex justify-between">
              <button 
                disabled={examState.currentQuestion === 0}
                onClick={() => setExamState({ ...examState, currentQuestion: examState.currentQuestion - 1 })}
                className="px-8 py-3 rounded-xl glass text-white font-bold disabled:opacity-20"
              >
                Previous
              </button>
              {examState.currentQuestion === activeExam.questions.length - 1 ? (
                <button onClick={handleExamFinish} className="btn-gradient px-12 py-3 rounded-xl text-white font-black uppercase tracking-widest">Submit Exam</button>
              ) : (
                <button 
                  onClick={() => setExamState({ ...examState, currentQuestion: examState.currentQuestion + 1 })}
                  className="px-8 py-3 rounded-xl bg-indigo-500 text-white font-bold"
                >
                  Next Question
                </button>
              )}
            </div>
          </GlassCard>
        </div>
      );
    }

    return (
      <div className="space-y-12 animate-fade-up">
        <header>
          <h2 className="text-4xl font-black text-white tracking-tighter">Live <span className="text-indigo-500">Exams</span></h2>
          <p className="text-white/40 font-medium">Take assessments for your enrolled modules.</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {exams.length === 0 && (
             <div className="col-span-full p-20 text-center glass border-dashed border-2 border-white/5 opacity-40">
                <p className="text-xs font-black uppercase tracking-widest">No active exams in your verified modules.</p>
             </div>
          )}
          {exams.map(exam => {
            const hasSubmitted = submissions.some(s => s.examId === exam.id && s.userId === user.id);
            const userSubmission = submissions.find(s => s.examId === exam.id && s.userId === user.id);
            
            return (
              <GlassCard key={exam.id} className="group relative overflow-hidden">
                <div className="mb-6 flex items-center justify-between">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 flex items-center justify-center text-xl">📝</div>
                  <span className={`text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-lg ${
                    exam.status === 'active' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-white/5 text-white/40'
                  }`}>
                    {exam.status === 'active' ? 'Live Now' : 'Completed'}
                  </span>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">{exam.title}</h3>
                <p className="text-xs text-white/40 mb-6 font-bold uppercase tracking-widest">{exam.questions.length} Questions • {exam.durationMinutes} Mins</p>
                
                {hasSubmitted ? (
                  <div className="pt-6 border-t border-white/5 space-y-4">
                    <div className="flex items-center justify-between">
                       <span className="text-xs font-bold text-white/20 uppercase">Your Performance</span>
                       <span className="text-xl font-black text-indigo-400">{userSubmission?.score}/{userSubmission?.totalQuestions}</span>
                    </div>
                    {userSubmission?.rank && (
                      <div className="bg-indigo-500/10 p-4 rounded-xl flex items-center justify-between border border-indigo-500/20 animate-fade-up">
                         <span className="text-xs font-black text-white uppercase tracking-widest">Global Position</span>
                         <span className="text-2xl font-black text-white">#{userSubmission.rank}</span>
                      </div>
                    )}
                  </div>
                ) : (
                  <button 
                    onClick={() => startExam(exam)}
                    disabled={exam.status !== 'active'}
                    className="w-full btn-gradient py-4 rounded-xl text-white font-black uppercase tracking-widest disabled:opacity-20"
                  >
                    Start Assessment
                  </button>
                )}
              </GlassCard>
            );
          })}
        </div>
      </div>
    );
  };

  const renderTeacherView = () => (
    <div className="space-y-12 animate-fade-up">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-4xl font-black text-white tracking-tighter">Exam <span className="text-indigo-500">Hub</span></h2>
          <p className="text-white/40 font-medium">Manage authored assessments and finalize results.</p>
        </div>
        <button 
          onClick={handleOpenCreate}
          disabled={teacherCourses.length === 0}
          className="btn-gradient px-8 py-4 rounded-2xl text-white font-black uppercase tracking-widest text-xs flex items-center gap-3 disabled:opacity-20"
        >
          <span>➕</span> Set Live Exam
        </button>
      </header>

      <div className="space-y-8">
        {exams.map(exam => {
          const examSubmissions = submissions.filter(s => s.examId === exam.id).sort((a, b) => b.score - a.score);
          const isRanked = examSubmissions.length > 0 && examSubmissions.every(s => s.rank !== undefined);
          
          return (
            <GlassCard key={exam.id} className="border-white/5">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8 mb-10">
                <div className="flex items-center gap-6">
                  <div className="w-16 h-16 rounded-[2rem] bg-indigo-500/20 flex items-center justify-center text-3xl">🎯</div>
                  <div>
                    <h3 className="text-2xl font-black text-white">{exam.title}</h3>
                    <div className="flex items-center gap-4 mt-1">
                      <span className="text-[10px] font-black uppercase tracking-widest text-indigo-400">{exam.questions.length} Questions</span>
                      <div className="w-1 h-1 rounded-full bg-white/20"></div>
                      <span className="text-[10px] font-black uppercase tracking-widest text-white/40">{examSubmissions.length} Participants</span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-4">
                  <button 
                    onClick={() => handleEditExam(exam)}
                    className="px-6 py-3 rounded-xl glass text-xs font-black uppercase tracking-widest text-white/60 hover:text-white transition-all"
                  >
                    Edit
                  </button>
                  <button 
                    onClick={() => onFinalizeResults(exam.id)}
                    disabled={examSubmissions.length === 0 || isRanked}
                    className="px-6 py-3 rounded-xl btn-gradient text-xs font-black uppercase tracking-widest text-white disabled:opacity-20"
                  >
                    {isRanked ? 'Results Finalized' : 'Finalize Ranking'}
                  </button>
                </div>
              </div>

              <div className="space-y-3">
                <div className="grid grid-cols-12 px-6 text-[10px] font-black text-white/20 uppercase tracking-widest mb-4">
                   <div className="col-span-1">Rank</div>
                   <div className="col-span-5">Student</div>
                   <div className="col-span-2">Score</div>
                   <div className="col-span-4 text-right">Submission Time</div>
                </div>
                {examSubmissions.length === 0 ? (
                  <div className="h-24 flex items-center justify-center text-white/10 font-black uppercase tracking-widest italic text-xs">Waiting for participants...</div>
                ) : (
                  examSubmissions.map((sub, idx) => (
                    <div key={sub.id} className={`grid grid-cols-12 items-center px-6 py-5 rounded-2xl border transition-all ${
                      sub.rank === 1 ? 'bg-indigo-500/10 border-indigo-500/30' : 'bg-white/5 border-white/5'
                    }`}>
                       <div className="col-span-1 font-black text-indigo-400">#{sub.rank || '-'}</div>
                       <div className="col-span-5 flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center font-bold text-xs">{sub.userName.charAt(0)}</div>
                          <span className="text-sm font-bold text-white">{sub.userName}</span>
                       </div>
                       <div className="col-span-2">
                          <span className="font-black text-lg text-white">{sub.score}</span>
                          <span className="text-xs text-white/40 ml-1">/ {sub.totalQuestions}</span>
                       </div>
                       <div className="col-span-4 text-right text-xs text-white/20 font-medium">
                          {new Date(sub.timestamp).toLocaleTimeString()}
                       </div>
                    </div>
                  ))
                )}
              </div>
            </GlassCard>
          );
        })}
      </div>

      {editingExam && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 overflow-y-auto">
          <div className="fixed inset-0 bg-black/95 backdrop-blur-xl" onClick={() => setEditingExam(null)}></div>
          <GlassCard className="relative w-full max-w-4xl p-0 border-indigo-500/30 shadow-[0_0_100px_rgba(99,102,241,0.2)] overflow-hidden flex flex-col max-h-[90vh]">
            <header className="p-8 border-b border-white/10 bg-indigo-500/10 flex items-center justify-between shrink-0">
               <div>
                  <h2 className="text-3xl font-black text-white tracking-tight">{editingExam.id ? 'Edit Live Exam' : 'Set New Live Exam'}</h2>
                  <p className="text-indigo-400 font-bold text-[10px] uppercase tracking-[0.2em] mt-1">Falconx Neural Assessment Editor</p>
               </div>
               <button onClick={() => setEditingExam(null)} className="p-2 text-white/20 hover:text-white">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg>
               </button>
            </header>

            <div className="flex-1 overflow-y-auto p-8 space-y-10 custom-scrollbar">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="md:col-span-1">
                  <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Associated Course</label>
                  <select 
                    value={editingExam.courseId} 
                    onChange={e => setEditingExam({ ...editingExam, courseId: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-indigo-500 transition-all appearance-none"
                  >
                    {teacherCourses.map(c => <option key={c.id} value={c.id} className="bg-slate-900">{c.title}</option>)}
                  </select>
                </div>
                <div className="md:col-span-1">
                  <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Exam Title</label>
                  <input 
                    value={editingExam.title} 
                    onChange={e => setEditingExam({ ...editingExam, title: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold placeholder:text-white/10 focus:outline-none focus:border-indigo-500 transition-all" 
                    placeholder="Mastering Cloud Infrastructure" 
                  />
                </div>
                <div className="md:col-span-1">
                  <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Time Limit (Minutes)</label>
                  <input 
                    type="number"
                    value={editingExam.durationMinutes} 
                    onChange={e => setEditingExam({ ...editingExam, durationMinutes: parseInt(e.target.value) || 30 })}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-indigo-500 transition-all" 
                    placeholder="30" 
                  />
                </div>
              </div>

              <div className="space-y-8">
                <div className="flex items-center justify-between">
                   <h3 className="text-xl font-black text-white tracking-tight">Question Set</h3>
                   <button 
                    onClick={addQuestion}
                    className="text-indigo-400 font-black uppercase text-[10px] tracking-widest hover:text-indigo-300 transition-colors flex items-center gap-2"
                   >
                     <span className="text-lg">+</span> Add Question
                   </button>
                </div>

                <div className="space-y-12">
                  {editingExam.questions?.map((q, qIdx) => (
                    <GlassCard key={qIdx} className="bg-white/5 border-white/5 p-8 relative group/q">
                      <button 
                        onClick={() => removeQuestion(qIdx)}
                        className="absolute top-4 right-4 text-white/10 hover:text-red-500 transition-colors"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                      </button>

                      <div className="space-y-6">
                        <div>
                          <label className="block text-[10px] font-black text-white/20 uppercase tracking-widest mb-3">Question {qIdx + 1}</label>
                          <textarea 
                            value={q.question}
                            onChange={e => updateQuestion(qIdx, 'question', e.target.value)}
                            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500 h-20 resize-none"
                            placeholder="Type your MCQ question here..."
                          />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {q.options.map((opt, oIdx) => (
                            <div key={oIdx} className="flex items-center gap-3">
                               <button 
                                onClick={() => updateQuestion(qIdx, 'correctAnswer', oIdx)}
                                className={`w-8 h-8 rounded-lg shrink-0 flex items-center justify-center border-2 transition-all font-black text-[10px] ${
                                  q.correctAnswer === oIdx ? 'bg-indigo-500 border-indigo-500 text-white' : 'border-white/10 text-white/20 hover:border-white/40'
                                }`}
                               >
                                 {String.fromCharCode(65 + oIdx)}
                               </button>
                               <input 
                                value={opt}
                                onChange={e => updateOption(qIdx, oIdx, e.target.value)}
                                className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                                placeholder={`Option ${oIdx + 1}`}
                               />
                            </div>
                          ))}
                        </div>
                      </div>
                    </GlassCard>
                  ))}
                </div>
              </div>
            </div>

            <footer className="p-8 border-t border-white/10 bg-slate-900/60 shrink-0">
               <button 
                onClick={handleSaveExam}
                className="w-full btn-gradient py-5 rounded-2xl text-white font-black uppercase tracking-[0.3em] shadow-2xl hover:scale-[1.02] transition-all"
               >
                 Authorize & Deploy Assessment
               </button>
            </footer>
          </GlassCard>
        </div>
      )}
    </div>
  );

  return (
    <div className="h-full">
      {role === UserRole.TEACHER ? renderTeacherView() : renderStudentView()}
    </div>
  );
};
