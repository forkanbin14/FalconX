
import React, { useState, useRef, useEffect } from 'react';
import { GlassCard } from './GlassCard';

interface PatternSetupProps {
  onSave: (pattern: number[]) => void;
  existingPattern: number[] | null;
}

export const PatternSetup: React.FC<PatternSetupProps> = ({ onSave, existingPattern }) => {
  const [selectedDots, setSelectedDots] = useState<number[]>([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const dotsCount = 9; // 3x3 grid

  const handleMouseDown = (index: number) => {
    setIsDrawing(true);
    setSelectedDots([index]);
  };

  const handleMouseEnter = (index: number) => {
    if (isDrawing && !selectedDots.includes(index)) {
      setSelectedDots(prev => [...prev, index]);
    }
  };

  const handleMouseUp = () => {
    setIsDrawing(false);
  };

  useEffect(() => {
    const handleGlobalMouseUp = () => setIsDrawing(false);
    window.addEventListener('mouseup', handleGlobalMouseUp);
    return () => window.removeEventListener('mouseup', handleGlobalMouseUp);
  }, []);

  const getDotPos = (index: number) => {
    const row = Math.floor(index / 3);
    const col = index % 3;
    return { x: col * 50 + 25, y: row * 50 + 25 }; // Relative percentage within SVG
  };

  const renderLines = () => {
    if (selectedDots.length < 2) return null;
    return selectedDots.map((dot, i) => {
      if (i === 0) return null;
      const start = getDotPos(selectedDots[i - 1]);
      const end = getDotPos(dot);
      return (
        <line
          key={i}
          x1={`${start.x}%`}
          y1={`${start.y}%`}
          x2={`${end.x}%`}
          y2={`${end.y}%`}
          stroke="#6366f1"
          strokeWidth="6"
          strokeLinecap="round"
          className="animate-fade-in"
        />
      );
    });
  };

  return (
    <GlassCard className="p-10 flex flex-col items-center border-indigo-500/30">
      <div className="text-center mb-8">
        <h3 className="text-2xl font-black text-white mb-2">Pattern Security Setup</h3>
        <p className="text-white/40 text-sm font-medium">Draw a secure pattern to authorize critical operations.</p>
        {existingPattern && (
          <span className="inline-block mt-4 px-3 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[8px] font-black uppercase tracking-widest rounded-full">
            Active Master Pattern Configured
          </span>
        )}
      </div>

      <div className="relative w-80 h-80 mb-10 bg-black/20 rounded-[3rem] p-8 border border-white/5 shadow-inner select-none">
        <svg className="absolute inset-0 w-full h-full pointer-events-none z-10">
          {renderLines()}
        </svg>
        
        <div className="grid grid-cols-3 gap-12 h-full relative z-20">
          {Array.from({ length: dotsCount }).map((_, i) => {
            const isSelected = selectedDots.includes(i);
            const isLast = selectedDots[selectedDots.length - 1] === i;
            
            return (
              <div 
                key={i}
                onMouseDown={() => handleMouseDown(i)}
                onMouseEnter={() => handleMouseEnter(i)}
                className="flex items-center justify-center relative cursor-crosshair group"
              >
                <div className={`w-5 h-5 rounded-full transition-all duration-300 border-4 ${
                  isSelected 
                    ? 'bg-white border-indigo-500 scale-125 shadow-[0_0_20px_rgba(99,102,241,0.6)]' 
                    : 'bg-white/10 border-transparent group-hover:bg-white/30'
                } ${isLast && isDrawing ? 'animate-pulse' : ''}`}></div>
                
                {/* Visual feedback rings */}
                {isSelected && (
                  <div className="absolute inset-0 rounded-full border-2 border-indigo-500/20 animate-ping"></div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="flex gap-4 w-full">
        <button 
          onClick={() => setSelectedDots([])}
          className="flex-1 py-4 glass rounded-2xl text-[10px] font-black uppercase tracking-widest text-white/40 hover:text-white transition-all"
        >
          Clear Grid
        </button>
        <button 
          onClick={() => {
            if (selectedDots.length < 4) {
              alert("Minimum 4 nodes required for security validation.");
              return;
            }
            onSave(selectedDots);
            setSelectedDots([]);
          }}
          className="flex-[2] py-4 btn-gradient rounded-2xl text-[10px] font-black uppercase tracking-widest text-white shadow-xl"
        >
          {existingPattern ? 'Update Pattern' : 'Initialize Pattern'}
        </button>
      </div>

      <div className="mt-8 grid grid-cols-3 gap-8 w-full border-t border-white/5 pt-8 opacity-40">
         <div className="text-center">
            <p className="text-[10px] font-black text-white/30 uppercase tracking-widest">Nodes</p>
            <p className="text-white font-bold">{selectedDots.length || '0'}</p>
         </div>
         <div className="text-center border-x border-white/5">
            <p className="text-[10px] font-black text-white/30 uppercase tracking-widest">Complexity</p>
            <p className={`font-bold ${selectedDots.length > 6 ? 'text-emerald-400' : selectedDots.length > 4 ? 'text-amber-400' : 'text-red-400'}`}>
              {selectedDots.length > 6 ? 'High' : selectedDots.length > 4 ? 'Mid' : 'Low'}
            </p>
         </div>
         <div className="text-center">
            <p className="text-[10px] font-black text-white/30 uppercase tracking-widest">Encryption</p>
            <p className="text-white font-bold">AES-256</p>
         </div>
      </div>
    </GlassCard>
  );
};
