
import React, { useState, useEffect, useRef } from 'react';
import { Course, Lesson, Material, LiveSchedule, UserRole, RecordedClass, Certificate } from '../types';
import { GlassCard } from './GlassCard';
import { geminiService } from '../services/geminiService';
import { FalconxLogo } from './FalconxLogo';
import { LiveClass } from './LiveClass';

interface CoursePlayerProps {
  course: Course;
  onBack: () => void;
  userRole?: UserRole;
  userName?: string;
  recordings?: RecordedClass[];
  isEnrolled?: boolean;
  certificate?: Certificate;
}

export const CoursePlayer: React.FC<CoursePlayerProps> = ({ 
  course, 
  onBack, 
  userRole = UserRole.STUDENT, 
  userName = "User", 
  recordings = [],
  isEnrolled = false,
  certificate
}) => {
  const [activeTab, setActiveTab] = useState<'live' | 'qna' | 'vault' | 'materials' | 'certificate'>('live');
  const [messages, setMessages] = useState<{ role: 'user' | 'model', text: string }[]>([
    { role: 'model', text: `Welcome to the live environment for "${course.title}". Ask anything about this module!` }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const activeLiveSession = (course.liveSchedules || []).find(s => s.isActive);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim() || isTyping) return;
    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsTyping(true);
    const context = `Course Title: ${course.title}\nModule Overview: ${course.description}`;
    const history = messages.map(m => ({ role: m.role, parts: [{ text: m.text }] }));
    const response = await geminiService.getAiTutorResponse(history, userMsg, context);
    setMessages(prev => [...prev, { role: 'model', text: response }]);
    setIsTyping(false);
  };

  // Guard for non-enrolled users attempting direct access
  if (!isEnrolled && userRole === UserRole.STUDENT) {
    return (
      <div className="h-[calc(100vh-8rem)] flex flex-col items-center justify-center text-center animate-fade-up">
        <div className="w-24 h-24 bg-red-500/10 rounded-[2rem] flex items-center justify-center mb-8 border border-red-500/20">
           <span className="text-5xl">🔒</span>
        </div>
        <h2 className="text-3xl font-black text-white mb-4">Ecosystem Access Denied</h2>
        <p className="text-white/40 max-w-md font-medium mb-8">You must be a verified member of this neural module to access live classes and recorded assets.</p>
        <button onClick={onBack} className="btn-gradient px-10 py-4 rounded-2xl text-white font-black uppercase tracking-widest text-xs">Return to Explorer</button>
      </div>
    );
  }

  const renderCertificate = () => (
    <div className="flex flex-col items-center space-y-12 animate-fade-up py-10">
      <div className="text-center">
        <h3 className="text-3xl font-black text-white tracking-tighter mb-2">My Module <span className="text-indigo-500">Credential</span></h3>
        <p className="text-white/40 font-medium">Verified completion of the {course.title} track.</p>
      </div>

      {!certificate ? (
        <div className="max-w-md w-full glass p-12 rounded-[2.5rem] border-dashed border-2 border-white/5 text-center flex flex-col items-center gap-6 opacity-60">
           <span className="text-6xl grayscale">🎓</span>
           <p className="text-xs font-black uppercase tracking-[0.2em] text-white/40 leading-relaxed">Credential Not Yet Synthesized.<br/>Complete all requirements to unlock.</p>
           <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden mt-4">
              <div className="h-full bg-indigo-500 w-[70%]"></div>
           </div>
           <p className="text-[9px] font-black text-indigo-400 uppercase tracking-widest">Progress: 70% towards mastery</p>
        </div>
      ) : (
        <div className="relative group max-w-4xl w-full">
           <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500 to-teal-400 rounded-[2.5rem] blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
           <div className="relative glass p-1 md:p-1 rounded-[2.5rem] border-white/10 overflow-hidden shadow-2xl">
              <div className="bg-[#0c1222] rounded-[2.3rem] p-10 md:p-16 border border-white/5 relative overflow-hidden">
                 {/* Certificate Background Elements */}
                 <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 blur-[100px] rounded-full"></div>
                 <div className="absolute bottom-0 left-0 w-64 h-64 bg-teal-500/5 blur-[100px] rounded-full"></div>
                 
                 <div className="flex flex-col items-center text-center relative z-10">
                    <FalconxLogo iconOnly={true} className="w-24 h-24 mb-10" animate={true} />
                    
                    <p className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.5em] mb-4">Neural Ecosystem Verification</p>
                    <h2 className="text-xl md:text-2xl font-bold text-white/50 uppercase tracking-[0.3em] mb-12">Certificate of Completion</h2>
                    
                    <p className="text-sm font-medium text-white/40 uppercase tracking-widest mb-4">This Master Class credential is awarded to</p>
                    <h1 className="text-5xl md:text-6xl font-black text-white tracking-tighter mb-8 bg-gradient-to-r from-white via-indigo-200 to-white bg-clip-text text-transparent">{certificate.studentName}</h1>
                    
                    <p className="text-sm font-medium text-white/40 uppercase tracking-widest mb-12 max-w-md mx-auto leading-relaxed">For the successful synthesis of all modules in the masterclass track of</p>
                    <h3 className="text-2xl md:text-3xl font-black text-indigo-400 tracking-tight mb-20">"{certificate.courseTitle}"</h3>
                    
                    <div className="grid grid-cols-2 gap-20 w-full pt-12 border-t border-white/5">
                       <div className="flex flex-col items-center">
                          <p className="text-lg font-bold text-white border-b border-white/20 pb-2 w-full">{certificate.instructorName}</p>
                          <p className="text-[9px] font-black text-white/30 uppercase tracking-widest mt-2">Lead Ecosystem Instructor</p>
                       </div>
                       <div className="flex flex-col items-center">
                          <p className="text-lg font-bold text-white border-b border-white/20 pb-2 w-full">{certificate.issueDate}</p>
                          <p className="text-[9px] font-black text-white/30 uppercase tracking-widest mt-2">Authorization Date</p>
                       </div>
                    </div>

                    <div className="mt-16 pt-8 border-t border-white/5 w-full flex justify-between items-end">
                       <div className="text-left">
                          <p className="text-[8px] font-black text-white/20 uppercase tracking-widest">Credential ID</p>
                          <p className="text-[10px] font-bold text-indigo-400 font-mono">{certificate.id}</p>
                       </div>
                       <div className="text-right">
                          <p className="text-[8px] font-black text-white/20 uppercase tracking-widest">Verification Hash</p>
                          <p className="text-[8px] font-bold text-white/40 font-mono truncate max-w-[150px]">{certificate.hash}</p>
                       </div>
                    </div>
                 </div>
              </div>
           </div>

           <div className="mt-12 flex justify-center gap-4">
              <button 
                onClick={() => window.print()} 
                className="btn-gradient px-12 py-4 rounded-2xl text-white font-black uppercase tracking-widest text-xs flex items-center gap-3 shadow-2xl hover:scale-105 transition-all"
              >
                <span>📥</span> Download PDF Credential
              </button>
              <button 
                onClick={() => alert("Credential verification link copied!")}
                className="px-8 py-4 glass rounded-2xl text-white/60 font-black uppercase tracking-widest text-xs hover:bg-white/10 transition-all"
              >
                Share Recognition
              </button>
           </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="flex h-[calc(100vh-8rem)] gap-6 animate-fade-up overflow-hidden">
      <div className="flex-1 flex flex-col gap-6 overflow-hidden">
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-6">
            <button onClick={onBack} className="text-white/40 hover:text-white group">
              <span className="group-hover:-translate-x-1 transition-transform">←</span>
            </button>
            <div>
              <h2 className="text-3xl font-black text-white tracking-tighter truncate max-w-md">{course.title}</h2>
              <div className="flex items-center gap-3 mt-1">
                 <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                 <span className="text-[9px] font-black text-emerald-400 uppercase tracking-widest">Secure Link Established</span>
              </div>
            </div>
          </div>
          <div className="flex bg-white/5 p-1 rounded-2xl border border-white/10 shrink-0 overflow-x-auto no-scrollbar">
            <button onClick={() => setActiveTab('live')} className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 whitespace-nowrap ${activeTab === 'live' ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/20' : 'text-white/40'}`}>
              {activeLiveSession && <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></span>}
              Live Class
            </button>
            <button onClick={() => setActiveTab('vault')} className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${activeTab === 'vault' ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/20' : 'text-white/40'}`}>Recording Vault</button>
            <button onClick={() => setActiveTab('materials')} className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${activeTab === 'materials' ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/20' : 'text-white/40'}`}>Slides & Nodes</button>
            <button onClick={() => setActiveTab('certificate')} className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${activeTab === 'certificate' ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/20' : 'text-white/40'}`}>Certificate</button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto pr-2 space-y-6 custom-scrollbar">
          {activeTab === 'live' && (
            <div className="h-full">
               {activeLiveSession ? (
                 <LiveClass role={userRole} userName={userName} courseTitle={course.title} />
               ) : (
                 <div className="h-full flex flex-col items-center justify-center text-center p-12 glass rounded-[2.5rem] border-white/5 bg-white/[0.01]">
                   <div className="w-20 h-20 bg-indigo-500/10 rounded-full flex items-center justify-center mb-6">
                      <span className="text-4xl">📡</span>
                   </div>
                   <h3 className="text-2xl font-black text-white mb-2">Sync Point Standby</h3>
                   <p className="text-white/30 text-sm max-w-sm font-medium">There is currently no active broadcast for this module. Check the schedule or enter the vault for past recordings.</p>
                   
                   {(course.liveSchedules || []).filter(s => !s.isCompleted).length > 0 && (
                     <GlassCard className="mt-8 border-indigo-500/20 bg-indigo-500/5 p-8 max-w-md w-full animate-spring-up">
                        <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-2">Next Scheduled Transmission</p>
                        <p className="text-xl font-bold text-white mb-4">{course.liveSchedules?.find(s => !s.isCompleted)?.topic}</p>
                        <div className="flex justify-between items-center pt-4 border-t border-white/10">
                           <span className="text-xs font-bold text-white/60">{new Date(course.liveSchedules?.[0]?.startTime || '').toLocaleString()}</span>
                           <span className="px-3 py-1 bg-white/5 rounded-lg text-[10px] font-black text-white/40 uppercase">Pending</span>
                        </div>
                     </GlassCard>
                   )}
                 </div>
               )}
            </div>
          )}

          {activeTab === 'vault' && (
            <div className="space-y-8">
               <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-black text-white tracking-tight">Masterclass Archives</h3>
                  <span className="text-[10px] font-black text-white/20 uppercase tracking-widest">{recordings.length} Saved Sessions</span>
               </div>
               {recordings.length === 0 ? (
                 <div className="text-center p-20 glass rounded-[2rem] border-dashed border-2 border-white/5 opacity-40">
                    <p className="text-xs font-black uppercase tracking-widest">No past recordings in this module yet.</p>
                 </div>
               ) : (
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {recordings.map(rec => (
                      <GlassCard key={rec.id} className="p-0 overflow-hidden border-white/5 group relative">
                        <div className="relative h-44">
                          <img src={rec.thumbnail} className="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-all duration-700" />
                          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all">
                             <div className="w-14 h-14 rounded-full btn-gradient flex items-center justify-center shadow-2xl border-2 border-white/20">
                                <svg className="w-6 h-6 text-white ml-1" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                             </div>
                          </div>
                          <div className="absolute bottom-3 right-3 bg-black/60 px-2 py-1 rounded text-[10px] font-black text-white">{rec.duration}</div>
                        </div>
                        <div className="p-6">
                           <h4 className="font-bold text-white mb-2 truncate">{rec.title}</h4>
                           <div className="flex items-center justify-between">
                              <span className="text-[9px] font-black text-white/30 uppercase tracking-widest">{rec.date}</span>
                              <div className="flex items-center gap-2">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                <span className="text-[9px] font-black text-emerald-400 uppercase tracking-widest">HQ Playback</span>
                              </div>
                           </div>
                        </div>
                      </GlassCard>
                    ))}
                 </div>
               )}
            </div>
          )}

          {activeTab === 'materials' && (
            <div className="space-y-8">
               <h3 className="text-2xl font-black text-white tracking-tight">Resource Node</h3>
               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                 {course.lessons.map(lesson => (
                   lesson.materials?.map(m => (
                     <GlassCard key={m.id} className="p-6 border-white/5 hover:border-indigo-500/30 group">
                        <div className="w-12 h-12 bg-indigo-500/10 rounded-xl flex items-center justify-center text-2xl mb-6 group-hover:scale-110 transition-transform">
                          {m.type === 'pdf' ? '📄' : m.type === 'video' ? '🎬' : '📦'}
                        </div>
                        <h4 className="font-bold text-white text-sm mb-1 truncate">{m.title}</h4>
                        <p className="text-[9px] font-black text-white/20 uppercase tracking-widest mb-6">{lesson.title}</p>
                        <a 
                          href={m.url} 
                          className="w-full py-3 rounded-xl bg-white/5 flex items-center justify-center gap-2 text-[10px] font-black uppercase tracking-widest text-indigo-400 hover:bg-indigo-500 hover:text-white transition-all border border-indigo-500/10"
                        >
                          Download Asset
                          <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                        </a>
                     </GlassCard>
                   ))
                 ))}
                 {(!course.lessons.some(l => l.materials && l.materials.length > 0)) && (
                   <div className="col-span-full p-20 text-center glass border-dashed border-2 border-white/5 opacity-40 rounded-[2rem]">
                      <p className="text-xs font-black uppercase tracking-widest">No downloadable assets synchronized for this module.</p>
                   </div>
                 )}
               </div>
            </div>
          )}

          {activeTab === 'certificate' && renderCertificate()}
        </div>
      </div>

      {/* Side Chat - Always Contextual Q&A */}
      <div className="w-[380px] hidden xl:flex flex-col gap-6 shrink-0">
        <GlassCard className="flex-1 flex flex-col p-0 overflow-hidden border-indigo-500/20 shadow-2xl rounded-[2.5rem] bg-indigo-500/[0.02]">
          <div className="p-6 border-b border-white/10 bg-indigo-500/10 flex items-center justify-between">
             <div className="flex items-center gap-3">
               <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center p-1 border border-white/10">
                  <FalconxLogo iconOnly={true} animate={true} />
               </div>
               <div>
                  <h4 className="font-black text-xs text-white">Neural Q&A Pulse</h4>
                  <p className="text-[8px] text-emerald-400 font-black uppercase tracking-widest">Real-time context sync</p>
               </div>
             </div>
             <span className="text-[8px] font-black bg-indigo-500/20 text-indigo-400 px-2 py-1 rounded uppercase">Ecosystem Chat</span>
          </div>
          <div className="flex-1 overflow-y-auto p-6 space-y-4 custom-scrollbar">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-4 rounded-2xl text-xs md:text-sm leading-relaxed ${
                  m.role === 'user' 
                  ? 'bg-indigo-600 text-white rounded-tr-none shadow-lg' 
                  : 'glass bg-white/5 text-white/90 border border-white/10 rounded-tl-none shadow-xl'
                }`}>
                  {m.text}
                </div>
              </div>
            ))}
            {isTyping && <div className="text-[9px] font-black text-indigo-400 animate-pulse uppercase tracking-widest px-2 italic">Synthesizing response...</div>}
            <div ref={chatEndRef} />
          </div>
          <div className="p-5 bg-slate-900 border-t border-white/10">
            <div className="flex gap-2">
              <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSendMessage()} placeholder="Ask about this module..." className="flex-1 bg-white/5 border border-white/10 rounded-xl px-5 py-4 text-xs text-white focus:outline-none focus:border-indigo-500 transition-all font-medium" />
              <button onClick={handleSendMessage} className="p-4 bg-indigo-500 text-white rounded-xl shadow-lg hover:scale-105 transition-transform">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z"/></svg>
              </button>
            </div>
          </div>
        </GlassCard>

        <div className="glass p-8 rounded-[2rem] border-white/5 flex flex-col items-center justify-center text-center">
            <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mb-4">
               <span className="text-xl">🎓</span>
            </div>
            <p className="text-[10px] font-black text-white/30 uppercase tracking-widest mb-1">Learning Track</p>
            <p className="text-sm font-bold text-white truncate w-full px-2">{course.title}</p>
        </div>
      </div>
    </div>
  );
};
