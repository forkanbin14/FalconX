
import React, { useState, useRef, useEffect } from 'react';
import { User, ChatMessage, UserRole, ActiveStatus } from '../types';
import { GlassCard } from './GlassCard';

interface MessengerProps {
  currentUser: User;
  contacts: User[];
  messages: ChatMessage[];
  onSendMessage: (receiverId: string, text: string) => void;
  title: string;
  subtitle: string;
}

export const Messenger: React.FC<MessengerProps> = ({ 
  currentUser, 
  contacts, 
  messages, 
  onSendMessage,
  title,
  subtitle
}) => {
  const [selectedContact, setSelectedContact] = useState<User | null>(contacts[0] || null);
  const [input, setInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [selectedContact, messages]);

  const filteredMessages = selectedContact 
    ? messages.filter(m => 
        (m.senderId === currentUser.id && m.receiverId === selectedContact.id) ||
        (m.senderId === selectedContact.id && m.receiverId === currentUser.id)
      )
    : [];

  const handleSend = () => {
    if (!input.trim() || !selectedContact) return;
    onSendMessage(selectedContact.id, input);
    setInput('');
  };

  const getStatusColor = (status?: ActiveStatus) => {
    switch (status) {
      case 'online': return 'bg-emerald-500';
      case 'away': return 'bg-amber-500';
      case 'busy': return 'bg-red-500';
      case 'offline': return 'bg-slate-500';
      default: return 'bg-slate-500';
    }
  };

  return (
    <div className="h-[calc(100vh-12rem)] flex gap-6 animate-fade-up">
      {/* Contact List */}
      <GlassCard className="w-80 flex flex-col p-0 overflow-hidden border-white/5">
        <div className="p-6 border-b border-white/5 bg-white/5">
          <h3 className="text-xl font-black text-white tracking-tight">{title}</h3>
          <p className="text-[10px] text-white/30 font-bold uppercase tracking-widest mt-1">{subtitle}</p>
        </div>
        <div className="flex-1 overflow-y-auto custom-scrollbar">
          {contacts.length === 0 ? (
            <div className="p-10 text-center opacity-20">
              <p className="text-xs font-black uppercase tracking-widest">No contacts found</p>
            </div>
          ) : (
            contacts.map(contact => (
              <button
                key={contact.id}
                onClick={() => setSelectedContact(contact)}
                className={`w-full p-4 flex items-center gap-4 transition-all border-b border-white/5 ${
                  selectedContact?.id === contact.id ? 'bg-indigo-500/10' : 'hover:bg-white/5'
                }`}
              >
                <div className="relative">
                  <img 
                    src={contact.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${contact.id}`} 
                    className="w-12 h-12 rounded-2xl bg-white/5" 
                  />
                  <div className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 ${getStatusColor(contact.activeStatus)} rounded-full border-2 border-slate-900 shadow-xl`}></div>
                </div>
                <div className="text-left flex-1 min-w-0">
                  <p className={`font-bold text-sm truncate ${selectedContact?.id === contact.id ? 'text-indigo-400' : 'text-white'}`}>
                    {contact.name}
                  </p>
                  <p className="text-[10px] text-white/30 font-medium uppercase tracking-widest">{contact.role}</p>
                </div>
              </button>
            ))
          )}
        </div>
      </GlassCard>

      {/* Chat Area */}
      <GlassCard className="flex-1 flex flex-col p-0 overflow-hidden border-white/10 shadow-3xl rounded-[2.5rem] bg-black/10">
        {selectedContact ? (
          <>
            <header className="p-6 border-b border-white/10 bg-indigo-500/10 flex items-center gap-4">
              <div className="relative">
                <img src={selectedContact.avatar} className="w-10 h-10 rounded-xl" />
                <div className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 ${getStatusColor(selectedContact.activeStatus)} rounded-full border-2 border-[#1e1b4b]`}></div>
              </div>
              <div>
                <h4 className="font-black text-white tracking-tight">{selectedContact.name}</h4>
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${getStatusColor(selectedContact.activeStatus)} ${selectedContact.activeStatus === 'online' ? 'animate-pulse' : ''}`}></span>
                  <span className="text-[10px] text-indigo-400 font-black uppercase tracking-widest">
                    {selectedContact.activeStatus || 'offline'}
                  </span>
                </div>
              </div>
            </header>

            <div className="flex-1 overflow-y-auto p-8 space-y-6 custom-scrollbar">
              {filteredMessages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center opacity-10">
                  <span className="text-6xl mb-4">💬</span>
                  <p className="text-sm font-black uppercase tracking-widest">Start a conversation</p>
                </div>
              ) : (
                filteredMessages.map((msg, idx) => (
                  <div key={msg.id} className={`flex ${msg.senderId === currentUser.id ? 'justify-end' : 'justify-start'} animate-fade-up`}>
                    <div className={`max-w-[70%] group`}>
                       <div className={`p-4 rounded-[1.5rem] text-sm leading-relaxed ${
                         msg.senderId === currentUser.id 
                           ? 'bg-indigo-600 text-white rounded-tr-none' 
                           : 'bg-white/5 text-white/90 border border-white/5 rounded-tl-none'
                       }`}>
                          {msg.text}
                       </div>
                       <p className={`text-[8px] mt-1 font-black uppercase tracking-widest text-white/10 ${msg.senderId === currentUser.id ? 'text-right' : 'text-left'}`}>
                         {msg.timestamp}
                       </p>
                    </div>
                  </div>
                ))
              )}
              <div ref={chatEndRef} />
            </div>

            <div className="p-6 bg-slate-900/60 border-t border-white/10 backdrop-blur-2xl">
              <div className="flex items-center gap-4 bg-white/5 border border-white/10 rounded-2xl p-2 pl-4 focus-within:border-indigo-500/50 transition-all">
                <input 
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSend()}
                  placeholder="Type your message..."
                  className="flex-1 bg-transparent border-none text-sm text-white focus:outline-none placeholder:text-white/20"
                />
                <button 
                  onClick={handleSend}
                  disabled={!input.trim()}
                  className={`p-3 rounded-xl transition-all ${
                    !input.trim() ? 'text-white/10' : 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/20'
                  }`}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/></svg>
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-12 text-center opacity-20">
            <span className="text-9xl mb-8">📫</span>
            <h3 className="text-2xl font-black uppercase tracking-widest">Select a Contact</h3>
            <p className="mt-4 font-medium">Choose a contact from the sidebar to start messaging.</p>
          </div>
        )}
      </GlassCard>
    </div>
  );
};
