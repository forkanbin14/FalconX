
import React, { useState } from 'react';
import { RecordedClass } from '../types';
import { GlassCard } from './GlassCard';

interface RecordedClassesProps {
  recordings: RecordedClass[];
}

export const RecordedClasses: React.FC<RecordedClassesProps> = ({ recordings }) => {
  const [selectedRecording, setSelectedRecording] = useState<RecordedClass | null>(null);

  return (
    <div className="space-y-12 animate-fade-up">
      <header>
        <h2 className="text-4xl font-black text-white tracking-tighter">Recorded <span className="text-indigo-500">Masterclasses</span></h2>
        <p className="text-white/40 font-medium">Access past live sessions and download comprehensive slide notes.</p>
      </header>

      {selectedRecording ? (
        <div className="space-y-8 animate-spring-up">
          <button 
            onClick={() => setSelectedRecording(null)}
            className="text-white/40 hover:text-white text-sm flex items-center gap-2 group mb-4"
          >
            <span className="group-hover:-translate-x-1 transition-transform">←</span> Back to Vault
          </button>
          
          <GlassCard className="p-0 overflow-hidden border-indigo-500/20 shadow-2xl">
            <div className="aspect-video bg-black flex items-center justify-center relative group">
              <img 
                src={selectedRecording.thumbnail} 
                className="w-full h-full object-cover opacity-40 group-hover:scale-105 transition-transform duration-[2000ms]" 
                alt="Recording"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                 <div className="btn-gradient p-10 rounded-full shadow-[0_20px_50px_rgba(99,102,241,0.4)] cursor-pointer hover:scale-110 transition-all border-4 border-white/10">
                    <svg className="w-12 h-12 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                 </div>
              </div>
            </div>
            <div className="p-8 md:p-12">
               <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div>
                    <h3 className="text-3xl font-black text-white mb-2">{selectedRecording.title}</h3>
                    <p className="text-indigo-400 font-bold text-xs uppercase tracking-[0.2em]">{selectedRecording.instructorName} • Recorded on {new Date(selectedRecording.date).toLocaleDateString()}</p>
                  </div>
                  <a 
                    href={selectedRecording.slidesUrl} 
                    download
                    className="btn-gradient px-8 py-4 rounded-2xl text-white font-black uppercase tracking-widest text-xs flex items-center gap-3 shadow-xl hover:brightness-110 transition-all"
                  >
                    <span>📊</span> Download Slide Notes
                  </a>
               </div>
               <div className="mt-12 pt-8 border-t border-white/5">
                  <h4 className="text-[10px] font-black text-white/30 uppercase tracking-[0.3em] mb-6">Session Breakdown</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                     {[
                       { time: '00:15', label: 'Architecture Overview' },
                       { time: '12:40', label: 'Implementation Strategies' },
                       { time: '45:10', label: 'Interactive Q&A Session' }
                     ].map((point, i) => (
                       <div key={i} className="glass p-4 rounded-xl flex items-center gap-4 hover:bg-white/5 transition-all cursor-pointer border-white/5">
                          <span className="text-[10px] font-black text-indigo-400 bg-indigo-500/10 px-2 py-1 rounded">{point.time}</span>
                          <span className="text-xs font-bold text-white/70">{point.label}</span>
                       </div>
                     ))}
                  </div>
               </div>
            </div>
          </GlassCard>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {recordings.map((rec) => (
            <GlassCard 
              key={rec.id} 
              className="group p-0 overflow-hidden cursor-pointer border-white/5 hover:border-indigo-500/30 transition-all"
              onClick={() => setSelectedRecording(rec)}
            >
              <div className="relative h-48 overflow-hidden">
                <img src={rec.thumbnail} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={rec.title} />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-[2px]">
                   <div className="w-12 h-12 rounded-full glass border-white/20 flex items-center justify-center">
                      <svg className="w-6 h-6 text-white ml-1" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                   </div>
                </div>
                <div className="absolute bottom-3 right-3 bg-black/60 backdrop-blur-md px-2 py-1 rounded text-[10px] font-black text-white border border-white/10 uppercase tracking-widest">
                  {rec.duration}
                </div>
              </div>
              <div className="p-6">
                 <h4 className="text-lg font-extrabold text-white mb-1 group-hover:text-indigo-400 transition-colors truncate">{rec.title}</h4>
                 <p className="text-[10px] text-white/30 font-bold uppercase tracking-widest mb-6">{rec.instructorName}</p>
                 <div className="flex items-center justify-between pt-4 border-t border-white/5">
                    <span className="text-[10px] font-black text-white/20 uppercase">{new Date(rec.date).toLocaleDateString()}</span>
                    <div className="flex items-center gap-3">
                       <span className="text-[10px] font-black text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded">Slides Available</span>
                    </div>
                 </div>
              </div>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  );
};
