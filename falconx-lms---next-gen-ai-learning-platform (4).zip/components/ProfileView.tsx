
import React, { useState, useRef } from 'react';
import { User, UserRole, UserProfile as ProfileType } from '../types';
import { GlassCard } from './GlassCard';

interface ProfileViewProps {
  user: User;
  onUpdate: (updatedUser: User) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ user, onUpdate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [profile, setProfile] = useState<ProfileType>(user.profile || {
    bio: '',
    currentCity: '',
    division: 'Dhaka',
    educationLevel: 'SSC',
    institute: '',
    experience: '',
    subject: '',
    phone: '',
    age: 0,
    gender: 'Male',
    expertiseSubject: '',
    currentInstituteSubject: '',
    mentorshipSubject: ''
  });
  const [avatar, setAvatar] = useState(user.avatar);
  const [coverPic, setCoverPic] = useState(user.profile?.coverPic || 'https://picsum.photos/1200/400?random=profile');
  const [name, setName] = useState(user.name);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);

  const divisions = ['Dhaka', 'Chittagong', 'Rajshahi', 'Khulna', 'Barishal', 'Sylhet', 'Rangpur', 'Mymensingh'];
  const educationLevels = ['SSC', 'HSC', 'Undergrad', 'Postgrad', 'Professional'];

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, setter: (val: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setter(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    const updatedUser: User = {
      ...user,
      name,
      avatar,
      profile: {
        ...profile,
        coverPic
      }
    };
    onUpdate(updatedUser);
    setIsEditing(false);
  };

  const isTeacher = user.role === UserRole.TEACHER;

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-fade-up">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-4xl font-black text-white tracking-tighter">
            {user.role === UserRole.TEACHER ? 'Instructor' : 'Student'} <span className="text-indigo-500">Profile</span>
          </h2>
          <p className="text-white/40 font-medium">Manage your identity in the Falconx ecosystem.</p>
        </div>
        <button 
          onClick={() => isEditing ? handleSave() : setIsEditing(true)}
          className={`btn-gradient px-8 py-3 rounded-2xl text-white font-black uppercase tracking-widest text-xs flex items-center gap-3 shadow-2xl transition-all ${isEditing ? 'bg-emerald-500' : ''}`}
        >
          {isEditing ? '💾 Save Identity' : '✏️ Edit Profile'}
        </button>
      </header>

      {/* Cover and Avatar Section */}
      <div className="relative">
        <div className="h-64 md:h-80 w-full rounded-[2.5rem] overflow-hidden glass border-white/10 relative group">
          <img src={coverPic} alt="Cover" className="w-full h-full object-cover" />
          {isEditing && (
            <button 
              onClick={() => coverInputRef.current?.click()}
              className="absolute inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all cursor-pointer"
            >
              <div className="text-white text-center">
                <span className="text-3xl">🖼️</span>
                <p className="text-xs font-black uppercase tracking-widest mt-2">Change Cover Photo</p>
              </div>
            </button>
          )}
          <input type="file" ref={coverInputRef} className="hidden" accept="image/*" onChange={(e) => handleImageUpload(e, setCoverPic)} />
        </div>

        <div className="absolute -bottom-16 left-12 group">
          <div className="w-40 h-40 rounded-[2.5rem] glass border-4 border-slate-900 overflow-hidden relative shadow-2xl">
            <img src={avatar} alt={name} className="w-full h-full object-cover" />
            {isEditing && (
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="absolute inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all cursor-pointer"
              >
                <div className="text-white text-center">
                  <span className="text-2xl">📸</span>
                </div>
              </button>
            )}
          </div>
          <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={(e) => handleImageUpload(e, setAvatar)} />
          {user.isVerified && (
            <div className={`absolute -bottom-2 -right-2 w-10 h-10 ${isTeacher ? 'bg-indigo-500' : 'bg-emerald-500'} rounded-full border-4 border-slate-900 shadow-lg flex items-center justify-center text-white text-lg z-10`}>
              ✓
            </div>
          )}
        </div>
      </div>

      <div className="pt-20 grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-4 space-y-6">
          <GlassCard className="p-8 border-indigo-500/20">
            <div className="space-y-6">
              <div>
                <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-2 ml-1">Full Name</label>
                <div className="flex items-center gap-3">
                  {isEditing ? (
                    <input 
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-white font-bold focus:outline-none focus:border-indigo-500"
                    />
                  ) : (
                    <>
                      <p className="text-2xl font-black text-white">{name}</p>
                      {user.isVerified && (
                        <div className={`w-5 h-5 rounded-full ${isTeacher ? 'bg-indigo-500' : 'bg-emerald-500'} flex items-center justify-center text-white text-[10px] shadow-sm`}>
                          ✓
                        </div>
                      )}
                    </>
                  )}
                </div>
              </div>
              
              <div>
                <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-2 ml-1">Gmail Address</label>
                <p className="text-white/60 font-medium text-sm">{user.email}</p>
              </div>

              <div>
                <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-2 ml-1">Phone</label>
                {isEditing ? (
                  <input 
                    value={profile.phone}
                    onChange={(e) => setProfile({...profile, phone: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-white font-bold focus:outline-none focus:border-indigo-500"
                  />
                ) : (
                  <p className="text-white font-bold">{profile.phone || 'Not linked'}</p>
                )}
              </div>

              <div>
                <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-2 ml-1">Account Role</label>
                <span className={`text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-lg border ${
                  user.isVerified 
                    ? (isTeacher ? 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20' : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20')
                    : 'bg-white/5 text-white/30 border-white/10'
                }`}>
                  {user.isVerified ? `Verified ${user.role.toLowerCase()}` : `Unverified ${user.role.toLowerCase()}`}
                </span>
              </div>
            </div>
          </GlassCard>

          <GlassCard className={`p-8 border-white/5 ${isTeacher ? 'bg-indigo-500/5' : 'bg-emerald-500/5'}`}>
             <div className="flex items-center justify-between mb-4">
               <h4 className={`text-[10px] font-black uppercase tracking-widest ${isTeacher ? 'text-indigo-400' : 'text-emerald-400'}`}>
                 {isTeacher ? 'Teaching Impact' : 'Falcon Pulse'}
               </h4>
               <span className={`text-[10px] font-black ${isTeacher ? 'text-indigo-400/50' : 'text-emerald-400/50'}`}>
                 {isTeacher ? 'Top Tier' : '84%'}
               </span>
             </div>
             <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                <div className={`h-full ${isTeacher ? 'bg-indigo-500' : 'bg-emerald-500'} w-[84%] animate-pulse`}></div>
             </div>
          </GlassCard>
        </div>

        <div className="lg:col-span-8 space-y-8">
          <GlassCard className="p-10 space-y-8">
            <div className="space-y-6">
              <h3 className="text-xl font-black text-white tracking-tight border-b border-white/5 pb-4">Demographics & Context</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Current City</label>
                  {isEditing ? (
                    <input 
                      value={profile.currentCity}
                      onChange={(e) => setProfile({...profile, currentCity: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-indigo-500"
                    />
                  ) : (
                    <p className="text-white font-bold">{profile.currentCity || 'Not specified'}</p>
                  )}
                </div>

                <div>
                  <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Division</label>
                  {isEditing ? (
                    <select 
                      value={profile.division}
                      onChange={(e) => setProfile({...profile, division: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-indigo-500 appearance-none"
                    >
                      {divisions.map(d => <option key={d} value={d} className="bg-slate-900">{d}</option>)}
                    </select>
                  ) : (
                    <p className="text-white font-bold">{profile.division || 'Not specified'}</p>
                  )}
                </div>

                <div>
                  <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Age</label>
                  {isEditing ? (
                    <input 
                      type="number"
                      value={profile.age}
                      onChange={(e) => setProfile({...profile, age: parseInt(e.target.value) || 0})}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-indigo-500"
                    />
                  ) : (
                    <p className="text-white font-bold">{profile.age || 'Not specified'}</p>
                  )}
                </div>

                <div>
                  <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Gender</label>
                  {isEditing ? (
                    <select 
                      value={profile.gender}
                      onChange={(e) => setProfile({...profile, gender: e.target.value as any})}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-indigo-500 appearance-none"
                    >
                      <option value="Male" className="bg-slate-900">Male</option>
                      <option value="Female" className="bg-slate-900">Female</option>
                      <option value="Other" className="bg-slate-900">Other</option>
                    </select>
                  ) : (
                    <p className="text-white font-bold">{profile.gender || 'Not specified'}</p>
                  )}
                </div>
              </div>
            </div>

            <div className="space-y-6 pt-8 border-t border-white/5">
              <h3 className="text-xl font-black text-white tracking-tight pb-4">Professional Background</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="md:col-span-2">
                  <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Institute</label>
                  {isEditing ? (
                    <input 
                      value={profile.institute}
                      onChange={(e) => setProfile({...profile, institute: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-indigo-500"
                    />
                  ) : (
                    <p className="text-white font-bold">{profile.institute || 'Not specified'}</p>
                  )}
                </div>

                {isTeacher ? (
                  <>
                    <div>
                      <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Expertise Subject</label>
                      {isEditing ? (
                        <input 
                          value={profile.expertiseSubject}
                          onChange={(e) => setProfile({...profile, expertiseSubject: e.target.value})}
                          className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-indigo-500"
                        />
                      ) : (
                        <p className="text-white font-bold">{profile.expertiseSubject || 'Not specified'}</p>
                      )}
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Current Subject in Institute</label>
                      {isEditing ? (
                        <input 
                          value={profile.currentInstituteSubject}
                          onChange={(e) => setProfile({...profile, currentInstituteSubject: e.target.value})}
                          className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-indigo-500"
                        />
                      ) : (
                        <p className="text-white font-bold">{profile.currentInstituteSubject || 'Not specified'}</p>
                      )}
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Subject to Mentor</label>
                      {isEditing ? (
                        <input 
                          value={profile.mentorshipSubject}
                          onChange={(e) => setProfile({...profile, mentorshipSubject: e.target.value})}
                          className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-indigo-500"
                        />
                      ) : (
                        <p className="text-white font-bold">{profile.mentorshipSubject || 'Not specified'}</p>
                      )}
                    </div>
                  </>
                ) : (
                  <div>
                    <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Target Subject</label>
                    {isEditing ? (
                      <input 
                        value={profile.subject}
                        onChange={(e) => setProfile({...profile, subject: e.target.value})}
                        className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-indigo-500"
                      />
                    ) : (
                      <p className="text-white font-bold">{profile.subject || 'Not specified'}</p>
                    )}
                  </div>
                )}
              </div>
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  );
};
