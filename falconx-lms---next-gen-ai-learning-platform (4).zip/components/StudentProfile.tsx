
import React, { useState, useRef } from 'react';
// Fix: StudentProfile does not exist in types.ts, using UserProfile instead
import { User, UserProfile as ProfileType } from '../types';
import { GlassCard } from './GlassCard';

interface StudentProfileProps {
  user: User;
  onUpdate: (updatedUser: User) => void;
}

export const StudentProfile: React.FC<StudentProfileProps> = ({ user, onUpdate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [profile, setProfile] = useState<ProfileType>(user.profile || {
    bio: '',
    currentCity: '',
    division: 'Dhaka',
    educationLevel: 'SSC',
    institute: ''
  });
  const [avatar, setAvatar] = useState(user.avatar);
  const [coverPic, setCoverPic] = useState(user.profile?.coverPic || 'https://picsum.photos/1200/400?random=profile');
  const [name, setName] = useState(user.name);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);

  const divisions = ['Dhaka', 'Chittagong', 'Rajshahi', 'Khulna', 'Barishal', 'Sylhet', 'Rangpur', 'Mymensingh'];
  const educationLevels = ['SSC', 'HSC', 'Undergrad', 'Postgrad', 'Professional'];

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, setter: (val: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setter(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    const updatedUser: User = {
      ...user,
      name,
      avatar,
      profile: {
        ...profile,
        coverPic
      }
    };
    onUpdate(updatedUser);
    setIsEditing(false);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-fade-up">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-4xl font-black text-white tracking-tighter">Student <span className="text-indigo-500">Profile</span></h2>
          <p className="text-white/40 font-medium">Manage your identity in the Falconx ecosystem.</p>
        </div>
        <button 
          onClick={() => isEditing ? handleSave() : setIsEditing(true)}
          className={`btn-gradient px-8 py-3 rounded-2xl text-white font-black uppercase tracking-widest text-xs flex items-center gap-3 shadow-2xl transition-all ${isEditing ? 'bg-emerald-500' : ''}`}
        >
          {isEditing ? '💾 Save Identity' : '✏️ Edit Profile'}
        </button>
      </header>

      {/* Cover and Avatar Section */}
      <div className="relative">
        <div className="h-64 md:h-80 w-full rounded-[2.5rem] overflow-hidden glass border-white/10 relative group">
          <img src={coverPic} alt="Cover" className="w-full h-full object-cover" />
          {isEditing && (
            <button 
              onClick={() => coverInputRef.current?.click()}
              className="absolute inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all cursor-pointer"
            >
              <div className="text-white text-center">
                <span className="text-3xl">🖼️</span>
                <p className="text-xs font-black uppercase tracking-widest mt-2">Change Cover Photo</p>
              </div>
            </button>
          )}
          <input type="file" ref={coverInputRef} className="hidden" accept="image/*" onChange={(e) => handleImageUpload(e, setCoverPic)} />
        </div>

        {/* Avatar */}
        <div className="absolute -bottom-16 left-12 group">
          <div className="w-40 h-40 rounded-[2.5rem] glass border-4 border-slate-900 overflow-hidden relative shadow-2xl">
            <img src={avatar} alt={name} className="w-full h-full object-cover" />
            {isEditing && (
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="absolute inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all cursor-pointer"
              >
                <div className="text-white text-center">
                  <span className="text-2xl">📸</span>
                </div>
              </button>
            )}
          </div>
          <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={(e) => handleImageUpload(e, setAvatar)} />
          <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-emerald-500 rounded-full border-4 border-slate-900 shadow-lg"></div>
        </div>
      </div>

      <div className="pt-20 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Basic Info */}
        <div className="lg:col-span-4 space-y-6">
          <GlassCard className="p-8 border-indigo-500/20">
            <div className="space-y-6">
              <div>
                <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-2 ml-1">Full Name</label>
                {isEditing ? (
                  <input 
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-white font-bold focus:outline-none focus:border-indigo-500"
                  />
                ) : (
                  <p className="text-2xl font-black text-white">{name}</p>
                )}
              </div>
              
              <div>
                <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-2 ml-1">Gmail Address</label>
                <p className="text-white/60 font-medium text-sm">{user.email}</p>
              </div>

              <div>
                <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-2 ml-1">Account Role</label>
                <span className="bg-indigo-500/10 text-indigo-400 text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-lg border border-indigo-500/20">
                  Verified Student
                </span>
              </div>
            </div>
          </GlassCard>

          <GlassCard className="p-8 border-white/5 bg-emerald-500/5">
             <div className="flex items-center justify-between mb-4">
               <h4 className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">Falcon Pulse</h4>
               <span className="text-[10px] font-black text-emerald-400/50">84%</span>
             </div>
             <div className="w-full h-1.5 bg-emerald-500/10 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 w-[84%] animate-pulse"></div>
             </div>
             <p className="text-[10px] text-white/30 font-medium mt-4 italic">"Consistency is the key to mastery. You are in the top 15% of active learners."</p>
          </GlassCard>
        </div>

        {/* Right Column: Extended Details */}
        <div className="lg:col-span-8 space-y-8">
          <GlassCard className="p-10 space-y-8">
            <div className="space-y-6">
              <h3 className="text-xl font-black text-white tracking-tight border-b border-white/5 pb-4">Personal Narrative</h3>
              <div>
                <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Bio / About Me</label>
                {isEditing ? (
                  <textarea 
                    value={profile.bio}
                    onChange={(e) => setProfile({...profile, bio: e.target.value})}
                    placeholder="Tell your story..."
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-medium focus:outline-none focus:border-indigo-500 transition-all h-32 resize-none"
                  />
                ) : (
                  <p className="text-white/70 leading-relaxed font-medium italic">"{profile.bio || 'This student hasn\'t written a bio yet.'}"</p>
                )}
              </div>
            </div>

            <div className="space-y-6 pt-8 border-t border-white/5">
              <h3 className="text-xl font-black text-white tracking-tight pb-4">Demographics & Academic</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Current City</label>
                  {isEditing ? (
                    <input 
                      value={profile.currentCity}
                      onChange={(e) => setProfile({...profile, currentCity: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-indigo-500"
                    />
                  ) : (
                    <p className="text-white font-bold">{profile.currentCity || 'Not specified'}</p>
                  )}
                </div>

                <div>
                  <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Division</label>
                  {isEditing ? (
                    <select 
                      value={profile.division}
                      onChange={(e) => setProfile({...profile, division: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-indigo-500 appearance-none"
                    >
                      {divisions.map(d => <option key={d} value={d} className="bg-slate-900">{d}</option>)}
                    </select>
                  ) : (
                    <p className="text-white font-bold">{profile.division || 'Not specified'}</p>
                  )}
                </div>

                <div>
                  <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Education Level</label>
                  {isEditing ? (
                    <select 
                      value={profile.educationLevel}
                      onChange={(e) => setProfile({...profile, educationLevel: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-indigo-500 appearance-none"
                    >
                      {educationLevels.map(l => <option key={l} value={l} className="bg-slate-900">{l}</option>)}
                    </select>
                  ) : (
                    <p className="text-white font-bold">{profile.educationLevel || 'Not specified'}</p>
                  )}
                </div>

                <div>
                  <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Institute</label>
                  {isEditing ? (
                    <input 
                      value={profile.institute}
                      onChange={(e) => setProfile({...profile, institute: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-indigo-500"
                    />
                  ) : (
                    <p className="text-white font-bold">{profile.institute || 'Not specified'}</p>
                  )}
                </div>
              </div>
            </div>
          </GlassCard>

          {/* Social Proof Section (Mocked) */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
             {[
               { icon: '⭐', label: 'Badges', val: '12' },
               { icon: '🎯', label: 'Courses', val: '4' },
               { icon: '🔥', label: 'Streak', val: '15d' },
               { icon: '🏆', label: 'Points', val: '2.4k' }
             ].map((stat, i) => (
               <GlassCard key={i} className="flex flex-col items-center justify-center py-6 text-center border-white/5">
                 <span className="text-2xl mb-2">{stat.icon}</span>
                 <p className="text-lg font-black text-white">{stat.val}</p>
                 <p className="text-[8px] font-black uppercase tracking-widest text-white/20">{stat.label}</p>
               </GlassCard>
             ))}
          </div>
        </div>
      </div>
    </div>
  );
};
