
import React, { useState } from 'react';
import { GlassCard } from './GlassCard';
import { Course } from '../types';

interface PaymentModalProps {
  course: Course;
  onClose: () => void;
  onConfirm: (method: 'bkash' | 'nagad' | 'stripe', trxId: string) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({ course, onClose, onConfirm }) => {
  const [method, setMethod] = useState<'bkash' | 'nagad' | 'stripe'>('bkash');
  const [trxId, setTrxId] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const merchantNumber = "01968434302";

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!trxId && method !== 'stripe') return alert("Please enter Transaction ID");
    setIsProcessing(true);
    setTimeout(() => {
      onConfirm(method, trxId || 'STRIPE_AUTO_' + Math.random().toString(36).substr(2, 9));
      setIsProcessing(false);
    }, 2000);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(merchantNumber);
    alert("Number copied to clipboard!");
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 animate-fade-up">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={onClose} />
      
      <GlassCard className="relative w-full max-w-lg p-0 overflow-hidden border-indigo-500/30 shadow-[0_32px_128px_rgba(0,0,0,0.8)]">
        <div className="p-8 border-b border-white/10 bg-indigo-500/10 flex items-center justify-between">
          <div>
            <h3 className="text-2xl font-black text-white tracking-tighter">Secure Checkout</h3>
            <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest mt-1">Falconx Payment Gateway (BDT)</p>
          </div>
          <button onClick={onClose} className="text-white/20 hover:text-white transition-colors">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
        </div>

        <div className="p-8 space-y-8">
          <div className="flex items-center justify-between p-6 glass border-white/5 rounded-2xl">
            <div>
              <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-1">Enrolling In</p>
              <h4 className="font-bold text-white text-lg">{course.title}</h4>
            </div>
            <div className="text-right">
              <p className="text-[10px] font-black text-white/20 uppercase tracking-widest mb-1">Total Due</p>
              <p className="text-2xl font-black text-white">৳{course.price.toLocaleString()}</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="space-y-3">
              <label className="text-[10px] font-black text-white/30 uppercase tracking-widest ml-1">Select Payment Method</label>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { id: 'bkash', label: 'bKash', color: 'bg-[#D12053]' },
                  { id: 'nagad', label: 'Nagad', color: 'bg-[#F7941D]' },
                  { id: 'stripe', label: 'Stripe', color: 'bg-[#635BFF]' }
                ].map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setMethod(m.id as any)}
                    className={`relative overflow-hidden p-4 rounded-xl border-2 transition-all group ${
                      method === m.id ? 'border-indigo-500 bg-white/10' : 'border-white/5 bg-white/5 grayscale hover:grayscale-0'
                    }`}
                  >
                    <div className={`w-full h-1 absolute top-0 left-0 ${m.color}`}></div>
                    <span className="text-sm font-black text-white">{m.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {method !== 'stripe' && (
              <div className="animate-fade-up space-y-6">
                <div className="bg-indigo-500/5 border border-indigo-500/20 rounded-2xl p-6">
                  <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-4">Payment Instructions</p>
                  <p className="text-xs text-white/60 mb-6 leading-relaxed">
                    Please send <strong>৳{course.price.toLocaleString()}</strong> to our merchant number via the <strong>{method}</strong> app or USSD.
                  </p>
                  
                  <div className="flex items-center justify-between bg-black/40 p-4 rounded-xl border border-white/5 group">
                    <div>
                      <p className="text-[9px] font-black text-white/20 uppercase tracking-widest mb-1">Merchant Number</p>
                      <p className="text-xl font-black text-white tracking-widest">{merchantNumber}</p>
                    </div>
                    <button 
                      type="button"
                      onClick={copyToClipboard}
                      className="p-3 bg-white/5 hover:bg-indigo-500 rounded-xl text-white/40 hover:text-white transition-all shadow-lg"
                      title="Copy Number"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3"/></svg>
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Transaction ID (TrxID)</label>
                  <input 
                    required
                    value={trxId}
                    onChange={e => setTrxId(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-indigo-500 transition-all font-medium placeholder:text-white/10"
                    placeholder="Enter TrxID after payment"
                  />
                </div>
              </div>
            )}

            <button 
              disabled={isProcessing}
              className="w-full btn-gradient py-5 rounded-2xl text-white font-black uppercase tracking-[0.2em] shadow-xl text-sm transition-all flex items-center justify-center gap-3"
            >
              {isProcessing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Verifying...
                </>
              ) : 'Complete Purchase'}
            </button>
          </form>
        </div>
      </GlassCard>
    </div>
  );
};
