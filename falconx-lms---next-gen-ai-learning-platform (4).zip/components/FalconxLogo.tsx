
import React from 'react';

interface FalconxLogoProps {
  className?: string;
  animate?: boolean;
  iconOnly?: boolean;
}

export const FalconxLogo: React.FC<FalconxLogoProps> = ({ className = '', animate = false, iconOnly = false }) => {
  return (
    <div className={`flex flex-col items-center justify-center ${className}`}>
      <div className={`relative ${iconOnly ? 'w-full h-full' : 'w-full max-w-[180px] aspect-square'} flex items-center justify-center`}>
        {/* Figma-style outer ring */}
        <div className={`absolute inset-0 border border-[#2dd4bf]/20 rounded-full ${animate ? 'animate-[spin_10s_linear_infinite] opacity-100' : 'opacity-20'}`} style={{ borderStyle: 'dashed', borderWidth: '1px' }}></div>
        <div className={`absolute inset-4 border border-indigo-500/10 rounded-full ${animate ? 'animate-[spin_15s_linear_infinite_reverse] opacity-100' : 'opacity-10'}`}></div>
        
        <svg
          viewBox="0 0 200 200"
          className={`w-[85%] h-[85%] relative z-10 ${animate ? 'animate-logo-entrance' : ''}`}
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Main Neural Path - Path drawing animation */}
          <path
            d="M35 150L60 110L85 150M60 110L100 40L140 110M140 110L165 150M100 40L125 100M85 150L115 150"
            stroke="url(#bodyGradient)"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            className={animate ? 'logo-draw' : ''}
          />

          {/* Glowing Peak */}
          <path
            d="M100 40L115 75L85 75L100 40Z"
            fill="url(#peakGradient)"
            className={animate ? 'animate-pulse' : ''}
          />

          {/* Interactive Nodes */}
          <g>
            <circle cx="100" cy="40" r="4" fill="#f59e0b" className={animate ? 'animate-ping opacity-70' : ''} />
            <circle cx="100" cy="40" r="3" fill="#f59e0b" />
            
            <circle cx="60" cy="110" r="3" fill="#2dd4bf" className={animate ? 'animate-pulse' : ''} />
            <circle cx="140" cy="110" r="3" fill="#2dd4bf" className={animate ? 'animate-pulse' : ''} />
            <circle cx="100" cy="75" r="2.5" fill="#indigo-400" />
          </g>

          <defs>
            <linearGradient id="peakGradient" x1="100" y1="40" x2="100" y2="75" gradientUnits="userSpaceOnUse">
              <stop stopColor="#fbbf24" />
              <stop offset="1" stopColor="#f59e0b" />
            </linearGradient>
            <linearGradient id="bodyGradient" x1="40" y1="40" x2="160" y2="160" gradientUnits="userSpaceOnUse">
              <stop stopColor="#1e1b4b" />
              <stop offset="0.5" stopColor="#2dd4bf" />
              <stop offset="1" stopColor="#6366f1" />
            </linearGradient>
          </defs>
        </svg>

        {/* Neural Glow Background */}
        {animate && (
          <div className="absolute inset-0 bg-indigo-500/10 blur-[50px] rounded-full animate-pulse"></div>
        )}
      </div>

      {!iconOnly && (
        <div className={`text-center mt-6 ${animate ? 'animate-logo-entrance' : ''}`}>
          <h1 className="text-4xl font-black tracking-tighter flex items-center justify-center gap-1">
            <span className="text-white">Falcon</span>
            <span className="text-[#2dd4bf] animate-pulse">x</span>
          </h1>
          <p className="text-[10px] font-black uppercase tracking-[0.4em] text-white/20 mt-1">Ecosystem Synthesis</p>
        </div>
      )}
    </div>
  );
};
