
import React, { useState, useRef } from 'react';
import { Course, Lesson, LiveSchedule, RecordedClass } from '../types';
import { GlassCard } from './GlassCard';

interface CourseEditorProps {
  course: Course;
  categories: string[];
  onSave: (updatedCourse: Course) => void;
  onCancel: () => void;
  onGoLive?: (course: Course) => void;
}

export const CourseEditor: React.FC<CourseEditorProps> = ({ course, categories, onSave, onCancel, onGoLive }) => {
  const [editedCourse, setEditedCourse] = useState<Course>({ ...course, liveSchedules: course.liveSchedules || [] });
  const [activeTab, setActiveTab] = useState<'details' | 'branding' | 'curriculum' | 'live'>('details');
  const coverInputRef = useRef<HTMLInputElement>(null);
  const thumbInputRef = useRef<HTMLInputElement>(null);

  const handleUpdateLesson = (id: string, field: keyof Lesson, value: any) => {
    const updatedLessons = editedCourse.lessons.map(l => 
      l.id === id ? { ...l, [field]: value } : l
    );
    setEditedCourse({ ...editedCourse, lessons: updatedLessons });
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, field: 'thumbnail' | 'coverImage') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditedCourse({ ...editedCourse, [field]: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const addLiveSchedule = () => {
    const newSchedule: LiveSchedule = {
      id: 'ls-' + Math.random().toString(36).substr(2, 5),
      topic: 'Live Q&A Session',
      startTime: new Date(Date.now() + 86400000).toISOString(),
      duration: '60m',
      isActive: false,
      isCompleted: false
    };
    setEditedCourse({ ...editedCourse, liveSchedules: [...(editedCourse.liveSchedules || []), newSchedule] });
  };

  const updateSchedule = (id: string, field: keyof LiveSchedule, value: any) => {
    const updatedSchedules = (editedCourse.liveSchedules || []).map(s => 
      s.id === id ? { ...s, [field]: value } : s
    );
    setEditedCourse({ ...editedCourse, liveSchedules: updatedSchedules });
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-fade-up">
      <header className="flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <button onClick={onCancel} className="text-white/40 hover:text-white text-sm mb-2 flex items-center gap-2 group">
             <span className="group-hover:-translate-x-1 transition-transform">←</span> Back to Dashboard
          </button>
          <h2 className="text-4xl font-black text-white tracking-tighter">Course <span className="text-indigo-500">Editor</span></h2>
          <p className="text-white/40 font-medium">Refining: {course.title}</p>
        </div>
        <div className="flex gap-4">
          <button 
            onClick={() => setEditedCourse({ ...editedCourse, status: editedCourse.status === 'published' ? 'draft' : 'published' })}
            className={`px-6 py-3 rounded-2xl border transition-all text-xs font-black uppercase tracking-widest ${
              editedCourse.status === 'published' ? 'border-emerald-500/50 text-emerald-400 bg-emerald-500/5' : 'border-white/10 text-white/40'
            }`}
          >
            {editedCourse.status === 'published' ? '● Published' : '○ Save as Draft'}
          </button>
          <button onClick={() => onSave(editedCourse)} className="btn-gradient px-8 py-3 rounded-2xl text-white font-black uppercase tracking-widest text-xs shadow-2xl">Deploy Changes</button>
        </div>
      </header>

      <div className="flex gap-6 border-b border-white/5 mb-8 overflow-x-auto pb-1 no-scrollbar">
        {[
          { id: 'details', label: 'Details' },
          { id: 'branding', label: 'Branding' },
          { id: 'curriculum', label: 'Curriculum' },
          { id: 'live', label: 'Live Sync' }
        ].map(tab => (
          <button 
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`pb-4 px-2 text-[10px] font-black uppercase tracking-widest transition-all relative whitespace-nowrap ${
              activeTab === tab.id ? 'text-indigo-400' : 'text-white/20 hover:text-white/40'
            }`}
          >
            {tab.label}
            {activeTab === tab.id && <div className="absolute bottom-0 left-0 w-full h-1 bg-indigo-500 rounded-full"></div>}
          </button>
        ))}
      </div>

      {activeTab === 'details' && (
        <GlassCard className="p-10 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div>
                <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Title</label>
                <input 
                  value={editedCourse.title}
                  onChange={e => setEditedCourse({ ...editedCourse, title: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Price (৳)</label>
                <input 
                  type="number"
                  value={editedCourse.price}
                  onChange={e => setEditedCourse({ ...editedCourse, price: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>
            <div>
              <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Full Description</label>
              <textarea 
                value={editedCourse.description}
                onChange={e => setEditedCourse({ ...editedCourse, description: e.target.value })}
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-medium focus:outline-none focus:border-indigo-500 h-[180px] resize-none"
              />
            </div>
          </div>
        </GlassCard>
      )}

      {activeTab === 'branding' && (
        <div className="space-y-8 animate-fade-up">
          <GlassCard className="p-8">
            <h3 className="text-xl font-black text-white mb-6">Course Cover Image</h3>
            <div 
              onClick={() => coverInputRef.current?.click()}
              className="relative aspect-[3/1] rounded-[2rem] bg-slate-900 border-2 border-dashed border-white/10 flex items-center justify-center cursor-pointer group overflow-hidden"
            >
              {editedCourse.coverImage ? (
                <img src={editedCourse.coverImage} className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-all" />
              ) : (
                <div className="text-center">
                  <span className="text-4xl mb-4 block">🖼️</span>
                  <p className="text-xs font-black uppercase tracking-widest text-white/20">Click to upload banner</p>
                </div>
              )}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-all">
                <span className="text-white font-black uppercase text-[10px] tracking-widest">Update Banner</span>
              </div>
            </div>
            <input type="file" ref={coverInputRef} className="hidden" accept="image/*" onChange={e => handleImageUpload(e, 'coverImage')} />
          </GlassCard>
        </div>
      )}

      {activeTab === 'curriculum' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center px-2">
            <h3 className="text-xl font-black text-white">Lesson Nodes</h3>
            <button className="text-indigo-400 font-black uppercase text-[10px] tracking-widest hover:text-indigo-300">+ Add Lesson</button>
          </div>
          {editedCourse.lessons.map((lesson) => (
            <GlassCard key={lesson.id} className="p-8 bg-white/5 border-white/5 relative group">
              <input 
                value={lesson.title}
                onChange={e => handleUpdateLesson(lesson.id, 'title', e.target.value)}
                className="w-full bg-transparent border-none text-xl font-black text-white mb-4 focus:outline-none"
              />
              <textarea 
                value={lesson.content}
                onChange={e => handleUpdateLesson(lesson.id, 'content', e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-6 py-4 text-white/70 text-sm h-32 resize-none"
              />
            </GlassCard>
          ))}
        </div>
      )}

      {activeTab === 'live' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center mb-4 px-2">
            <h3 className="text-xl font-black text-white">Broadcast Schedule</h3>
            <button onClick={addLiveSchedule} className="text-indigo-400 font-black uppercase text-[10px] tracking-widest hover:text-indigo-300">+ New Session</button>
          </div>
          {(editedCourse.liveSchedules || []).map((schedule) => (
            <GlassCard key={schedule.id} className="flex flex-col md:flex-row md:items-center justify-between gap-6 p-8 border-white/5">
              <div className="space-y-4 flex-1">
                <input 
                  value={schedule.topic}
                  onChange={e => updateSchedule(schedule.id, 'topic', e.target.value)}
                  className="bg-transparent border-none text-lg font-bold text-white w-full focus:outline-none"
                  placeholder="Topic name"
                />
                <div className="grid grid-cols-2 gap-4">
                  <input 
                    type="datetime-local"
                    value={schedule.startTime.substring(0, 16)}
                    onChange={e => updateSchedule(schedule.id, 'startTime', new Date(e.target.value).toISOString())}
                    className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white"
                  />
                  <input 
                    value={schedule.duration}
                    onChange={e => updateSchedule(schedule.id, 'duration', e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white"
                    placeholder="Duration (e.g. 1.5h)"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => {
                    updateSchedule(schedule.id, 'isActive', !schedule.isActive);
                    if (!schedule.isActive && onGoLive) {
                      onGoLive(editedCourse);
                    }
                  }}
                  className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${schedule.isActive ? 'bg-red-500 text-white shadow-lg shadow-red-500/20' : 'bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600 hover:text-white'}`}
                >
                  {schedule.isActive ? 'Stop Stream' : 'Begin Broadcast'}
                </button>
              </div>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  );
};
