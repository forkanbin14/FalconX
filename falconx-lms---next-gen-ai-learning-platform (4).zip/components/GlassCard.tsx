
import React from 'react';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  variant?: 'default' | 'flat' | 'active';
}

export const GlassCard: React.FC<GlassCardProps> = ({ children, className = '', onClick, variant = 'default' }) => {
  const baseClass = "glass-card p-6 rounded-[2rem]";
  const variants = {
    default: "",
    flat: "backdrop-blur-none shadow-none bg-white/5",
    active: "border-indigo-500/50 bg-indigo-500/5 ring-1 ring-indigo-500/20"
  };

  return (
    <div 
      onClick={onClick}
      className={`${baseClass} ${variants[variant]} ${onClick ? 'cursor-pointer' : ''} ${className}`}
    >
      {children}
    </div>
  );
};
