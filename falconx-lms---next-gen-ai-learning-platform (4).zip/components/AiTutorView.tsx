
import React, { useState, useRef, useEffect } from 'react';
import { GlassCard } from './GlassCard';
import { geminiService } from '../services/geminiService';
import { FalconxLogo } from './FalconxLogo';

// Audio decoding utilities
function decodeBase64(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export const AiTutorView: React.FC = () => {
  const [messages, setMessages] = useState<{ role: 'user' | 'model', text: string, timestamp: string, attachment?: { mimeType: string, data: string, name: string } }[]>([
    { 
      role: 'model', 
      text: "Assalamu Alaikum! Ami Falconx, apnar primary intelligence guide. Aajke amra ki niye kotha bolte pari? Modern Web Architecture naki Advanced React patterns?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [selectedFile, setSelectedFile] = useState<{ name: string, mimeType: string, data: string } | null>(null);
  const [isVoiceEnabled, setIsVoiceEnabled] = useState(true);
  const [isRecording, setIsRecording] = useState(false);
  const [detectedLang, setDetectedLang] = useState('Auto');
  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  useEffect(() => {
    // Initialize Web Speech API for Voice Input
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      // Use browser locale for better 'Auto' language support
      recognition.lang = navigator.language || 'en-US';

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput(prev => prev ? prev + ' ' + transcript : transcript);
        setIsRecording(false);
      };

      recognition.onerror = () => setIsRecording(false);
      recognition.onend = () => setIsRecording(false);
      recognitionRef.current = recognition;
    }
  }, []);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const base64Data = (reader.result as string).split(',')[1];
      setSelectedFile({
        name: file.name,
        mimeType: file.type,
        data: base64Data
      });
    };
    reader.readAsDataURL(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const toggleRecording = () => {
    if (isRecording) {
      recognitionRef.current?.stop();
    } else {
      setIsRecording(true);
      recognitionRef.current?.start();
    }
  };

  const playResponse = async (text: string) => {
    if (!isVoiceEnabled) return;

    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }
    const ctx = audioContextRef.current;
    
    // Use high-quality Zephyr voice
    const base64Audio = await geminiService.textToSpeech(text, 'Zephyr');
    if (base64Audio) {
      const audioBytes = decodeBase64(base64Audio);
      const audioBuffer = await decodeAudioData(audioBytes, ctx, 24000, 1);
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);
      source.start();
    }
  };

  const handleSend = async () => {
    if ((!input.trim() && !selectedFile) || isTyping) return;
    
    const msg = input;
    const attachment = selectedFile;
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    setInput('');
    setSelectedFile(null);

    setMessages(prev => [...prev, { 
      role: 'user', 
      text: msg, 
      timestamp: time,
      attachment: attachment ? { mimeType: attachment.mimeType, data: attachment.data, name: attachment.name } : undefined
    }]);
    
    setIsTyping(true);

    const history = messages.map(m => {
      const parts: any[] = [{ text: m.text }];
      if (m.attachment) {
        parts.unshift({ inlineData: { mimeType: m.attachment.mimeType, data: m.attachment.data } });
      }
      return { role: m.role, parts };
    });

    const currentParts: any[] = [];
    if (attachment) {
      currentParts.push({ inlineData: { mimeType: attachment.mimeType, data: attachment.data } });
    }
    currentParts.push({ text: msg || "Analyze this attachment for me." });

    try {
      const res = await geminiService.getAiTutorResponse(history, currentParts, "General educational topics and learning assistance.");
      const responseTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      setMessages(prev => [...prev, { role: 'model', text: res, timestamp: responseTime }]);
      
      if (isVoiceEnabled) {
        playResponse(res);
      }
      
      // Heuristic for UI feedback on language detection
      if (/[\u0980-\u09FF]/.test(msg)) {
        setDetectedLang('Bangla');
      } else if (msg.trim()) {
        setDetectedLang('English');
      }
    } catch (err) {
      setMessages(prev => [...prev, { role: 'model', text: "Shomoshya hoyeche! Abar try korun.", timestamp: time }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto h-[calc(100vh-12rem)] flex flex-col gap-8 animate-fade-up">
      <header className="flex flex-col items-center gap-4">
        <div className="relative group">
          <div className="absolute inset-0 bg-indigo-500/10 blur-[60px] rounded-full group-hover:bg-indigo-500/20 transition-all duration-700"></div>
          <div className="relative w-32 h-32 bg-white/5 backdrop-blur-xl rounded-[2.5rem] flex items-center justify-center shadow-2xl border border-white/10 transition-all duration-500 group-hover:border-indigo-500/30 p-2">
            <FalconxLogo iconOnly={true} animate={true} />
          </div>
          <div className="absolute -bottom-1 -right-1 w-7 h-7 bg-emerald-500 rounded-full border-4 border-slate-900 shadow-xl"></div>
        </div>
        <div className="text-center">
          <h2 className="text-4xl font-black text-white tracking-tighter mb-1">Falcon<span className="text-[#2dd4bf]">x</span></h2>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <div className="flex items-center gap-2">
               <span className="text-[10px] font-black uppercase tracking-[0.3em] text-white/30">Primary Neural Assistant</span>
               <div className="w-1 h-1 bg-indigo-500/50 rounded-full"></div>
               <span className="text-[10px] font-black uppercase tracking-[0.3em] text-emerald-400">Online</span>
            </div>
            
            <div className="flex items-center gap-3">
               {/* Language Auto-Detect Badge */}
               <div className="flex items-center gap-2 bg-indigo-500/10 border border-indigo-500/20 px-3 py-1 rounded-full">
                  <span className="text-[9px] font-black uppercase tracking-widest text-indigo-400">Lang Sync:</span>
                  <span className={`text-[9px] font-black uppercase tracking-widest text-white/80 ${isTyping ? 'animate-pulse' : ''}`}>{detectedLang}</span>
               </div>

               {/* Global Voice Toggle */}
               <button 
                onClick={() => setIsVoiceEnabled(!isVoiceEnabled)}
                className={`flex items-center gap-2 px-3 py-1 rounded-full border transition-all ${isVoiceEnabled ? 'bg-indigo-500/10 border-indigo-500/30 text-indigo-400' : 'bg-white/5 border-white/10 text-white/20'}`}
                title={isVoiceEnabled ? 'AI Voice Enabled' : 'AI Voice Disabled'}
               >
                 <span className="text-xs">{isVoiceEnabled ? '🔊' : '🔇'}</span>
                 <span className="text-[9px] font-black uppercase tracking-widest">{isVoiceEnabled ? 'Voice Active' : 'Voice Muted'}</span>
               </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex-1 flex flex-col min-h-0 bg-white/5 backdrop-blur-3xl rounded-[3rem] border border-white/10 shadow-[0_32px_120px_rgba(0,0,0,0.5)] overflow-hidden relative group">
        <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-indigo-500/5 blur-[120px] pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-1/2 h-1/2 bg-violet-500/5 blur-[120px] pointer-events-none"></div>

        <div className="flex-1 overflow-y-auto p-6 md:p-10 space-y-10 scroll-smooth custom-scrollbar">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-fade-up`}>
              <div className={`group relative flex flex-col max-w-[85%] md:max-w-[75%] ${m.role === 'user' ? 'items-end' : 'items-start'}`}>
                <div className={`flex items-center gap-3 mb-2 px-1 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
                  <span className="text-[9px] font-black text-white/20 uppercase tracking-widest">{m.role === 'model' ? 'Falconx' : 'You'}</span>
                  <span className="text-[8px] font-bold text-white/10">{m.timestamp}</span>
                </div>

                <div className={`relative px-6 py-5 rounded-[2rem] text-sm md:text-base leading-relaxed shadow-2xl transition-all ${
                  m.role === 'user' 
                    ? 'btn-gradient text-white rounded-tr-none hover:shadow-indigo-500/20' 
                    : 'glass bg-white/5 border border-white/10 text-white/90 rounded-tl-none hover:bg-white/10'
                }`}>
                  {m.attachment && (
                    <div className="mb-3 p-2 bg-black/20 rounded-xl border border-white/10 overflow-hidden">
                       {m.attachment.mimeType.startsWith('image/') ? (
                         <img src={`data:${m.attachment.mimeType};base64,${m.attachment.data}`} className="max-w-full rounded-lg" alt="attachment" />
                       ) : (
                         <div className="flex items-center gap-2 text-xs text-white/60">
                            <span>📄</span>
                            <span className="truncate max-w-[150px]">{m.attachment.name}</span>
                         </div>
                       )}
                    </div>
                  )}
                  <p className="font-medium whitespace-pre-wrap">{m.text}</p>
                </div>
                {m.role === 'model' && (
                  <button 
                    onClick={() => playResponse(m.text)}
                    className="absolute -right-8 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity text-white/20 hover:text-indigo-400 p-2"
                  >
                    🔊
                  </button>
                )}
              </div>
            </div>
          ))}
          {isTyping && (
             <div className="flex justify-start animate-fade-up">
               <div className="flex flex-col items-start max-w-[100px]">
                 <div className="text-[9px] font-black text-white/20 uppercase tracking-widest mb-2 px-1 italic">Falconx Thinking...</div>
                 <div className="glass px-6 py-4 rounded-[1.5rem] rounded-tl-none border-white/10 flex gap-2 items-center bg-white/5">
                    <div className="w-1.5 h-1.5 bg-[#2dd4bf] rounded-full animate-bounce"></div>
                    <div className="w-1.5 h-1.5 bg-[#2dd4bf] rounded-full animate-bounce [animation-delay:200ms]"></div>
                    <div className="w-1.5 h-1.5 bg-[#2dd4bf] rounded-full animate-bounce [animation-delay:400ms]"></div>
                 </div>
               </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        <div className="p-6 md:p-8 bg-black/20 border-t border-white/10 backdrop-blur-md">
          {selectedFile && (
            <div className="max-w-3xl mx-auto mb-4 animate-fade-up">
               <div className="inline-flex items-center gap-3 bg-white/10 border border-indigo-500/30 rounded-xl p-2 pr-4 relative">
                  <div className="w-10 h-10 rounded-lg bg-indigo-500/20 flex items-center justify-center overflow-hidden">
                    {selectedFile.mimeType.startsWith('image/') ? <img src={`data:${selectedFile.mimeType};base64,${selectedFile.data}`} className="w-full h-full object-cover" /> : '📄'}
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[10px] font-bold text-white truncate max-w-[150px]">{selectedFile.name}</span>
                    <span className="text-[8px] font-black text-indigo-400 uppercase">Ready to analyze</span>
                  </div>
                  <button 
                    onClick={() => setSelectedFile(null)}
                    className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 rounded-full text-white text-[10px] flex items-center justify-center shadow-lg border-2 border-slate-900"
                  >
                    ✕
                  </button>
               </div>
            </div>
          )}

          <div className="max-w-3xl mx-auto flex items-center gap-4 bg-white/5 border border-white/10 rounded-[2rem] p-2 pl-4 focus-within:ring-4 focus-within:ring-indigo-500/20 focus-within:border-indigo-500/40 transition-all shadow-xl group/input">
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              onChange={handleFileChange} 
              accept="image/*,.pdf,.txt"
            />
            
            <div className="flex items-center gap-1">
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="w-12 h-12 flex items-center justify-center rounded-[1.2rem] bg-white/5 text-white/30 hover:text-white hover:bg-white/10 transition-all"
                title="Attach File"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"/></svg>
              </button>

              <button 
                onClick={toggleRecording}
                className={`w-12 h-12 flex items-center justify-center rounded-[1.2rem] transition-all ${isRecording ? 'bg-red-500 text-white animate-pulse' : 'bg-white/5 text-white/30 hover:text-white hover:bg-white/10'}`}
                title={isRecording ? 'Stop Recording' : 'Voice Input'}
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"/></svg>
              </button>
            </div>

            <input 
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSend()}
              placeholder={isRecording ? "Listening & Detecting..." : "Ask Falconx anything..."}
              className="flex-1 bg-transparent border-none py-4 text-sm md:text-base text-white focus:outline-none placeholder:text-white/20 font-medium"
            />
            
            <div className="flex items-center gap-2 pr-2">
              <button 
                onClick={handleSend}
                disabled={(!input.trim() && !selectedFile) || isTyping}
                className={`w-12 h-12 flex items-center justify-center rounded-[1.2rem] shadow-xl transition-all transform active:scale-95 ${
                  (!input.trim() && !selectedFile) || isTyping 
                  ? 'bg-white/5 text-white/20 cursor-not-allowed'
                  : 'btn-gradient text-white hover:rotate-6 hover:scale-105'
                }`}
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/></svg>
              </button>
            </div>
          </div>
          <div className="mt-4 flex justify-center gap-8 text-[9px] font-black uppercase tracking-[0.2em] text-white/10">
            <span>Neural Language Sync</span>
            <span>Multimodal Context</span>
            <span>Adaptive Synthesis</span>
          </div>
        </div>
      </div>
    </div>
  );
};
