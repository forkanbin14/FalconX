
import React, { useState, useRef } from 'react';
import { GlassCard } from './GlassCard';
import { geminiService } from '../services/geminiService';
import { QuizGenerationResult, Difficulty, Course, User } from '../types';

interface CreateCourseProps {
  currentUser: User | null;
  categories: string[];
  onPublish: (course: Course) => void;
}

export const CreateCourse: React.FC<CreateCourseProps> = ({ currentUser, categories, onPublish }) => {
  const [title, setTitle] = useState('');
  const [topic, setTopic] = useState('');
  const [category, setCategory] = useState(categories[0] || '');
  const [content, setContent] = useState('');
  const [difficulty, setDifficulty] = useState<Difficulty>('Intermediate');
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<QuizGenerationResult | null>(null);
  const [thumbnail, setThumbnail] = useState<string>('');
  const [coverImage, setCoverImage] = useState<string>('');
  const [status, setStatus] = useState<'draft' | 'published'>('draft');
  const [creditAmount, setCreditAmount] = useState<string>('5000');

  const fileRef = useRef<HTMLInputElement>(null);

  const handleGenerateQuiz = async () => {
    if (!content || !topic) return alert("Please add both a topic and lesson content!");
    setIsGenerating(true);
    setResult(null);
    try {
      const generated = await geminiService.generateQuiz(topic, content, difficulty);
      setResult(generated);
    } catch (err) {
      alert("Failed to generate quiz. Try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePublish = () => {
    if (!title || !content || !currentUser) {
      alert("Missing course data for deployment.");
      return;
    }

    const newCourse: Course = {
      id: 'c-' + Math.random().toString(36).substr(2, 5),
      title: title,
      description: content.substring(0, 150) + "...",
      thumbnail: thumbnail || 'https://picsum.photos/600/400?random=' + Math.floor(Math.random() * 100),
      coverImage: coverImage,
      instructorId: currentUser.id,
      category: category,
      price: parseFloat(creditAmount) || 0,
      isApproved: false,
      status: status,
      lessons: [
        { id: 'l1', title: 'Phase 1: ' + topic, content: content }
      ],
      quizzes: []
    };

    onPublish(newCourse);
    alert(status === 'published' ? "Course launched to system. Pending admin review." : "Course saved to drafts.");
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12 animate-fade-up">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div>
          <h2 className="text-4xl font-black text-white tracking-tighter">New <span className="text-indigo-500">Masterclass</span></h2>
          <p className="text-white/40 font-medium text-sm">Design your curriculum and leverage Falconx AI synthesis.</p>
        </div>
        <div className="flex gap-4">
          <select 
            value={status} 
            onChange={(e) => setStatus(e.target.value as any)}
            className="bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white text-xs font-black uppercase tracking-widest focus:outline-none focus:border-indigo-500 appearance-none"
          >
            <option value="draft" className="bg-slate-900">Save Draft</option>
            <option value="published" className="bg-slate-900">Publish Live</option>
          </select>
          <button 
            onClick={handlePublish}
            className="btn-gradient px-8 py-4 rounded-2xl text-white font-black uppercase tracking-widest text-xs shadow-2xl"
          >
            Launch Asset
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-7 space-y-6">
          <GlassCard className="p-8 space-y-8">
            <div className="space-y-6">
              <div>
                <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Asset Identity (Title)</label>
                <input 
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-indigo-500 font-bold" 
                  placeholder="Mastering the Neural Network"
                />
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Domain</label>
                  <select 
                    value={category}
                    onChange={e => setCategory(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none appearance-none font-bold"
                  >
                    {categories.map(cat => <option key={cat} value={cat} className="bg-slate-900">{cat}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Complexity</label>
                  <select 
                    value={difficulty}
                    onChange={e => setDifficulty(e.target.value as Difficulty)}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none appearance-none font-bold"
                  >
                    <option value="Basic" className="bg-slate-900">Basic</option>
                    <option value="Intermediate" className="bg-slate-900">Intermediate</option>
                    <option value="Advanced" className="bg-slate-900">Advanced</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Module Credit Amount (৳)</label>
                <input 
                  type="number"
                  value={creditAmount}
                  onChange={e => setCreditAmount(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-indigo-500 font-bold" 
                  placeholder="5000"
                />
              </div>

              <div>
                <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Lesson Phase 1 (Topic)</label>
                <input 
                  value={topic}
                  onChange={e => setTopic(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-indigo-500" 
                  placeholder="Architecture Design"
                />
              </div>

              <div>
                <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Lesson Blueprint (Content)</label>
                <textarea 
                  value={content}
                  onChange={e => setContent(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-indigo-500 h-64 resize-none transition-all" 
                  placeholder="Input curriculum details..."
                />
              </div>
            </div>
          </GlassCard>
        </div>

        <div className="lg:col-span-5 space-y-6">
          <GlassCard className="bg-indigo-600/10 border-indigo-500/30 p-8">
            <h4 className="font-black text-[10px] uppercase tracking-[0.3em] text-indigo-400 mb-6 flex items-center gap-3">
               <span className="text-xl">🎨</span> Course Branding
            </h4>
            <div className="space-y-4">
              <div 
                onClick={() => fileRef.current?.click()}
                className="w-full aspect-video rounded-2xl bg-white/5 border border-dashed border-white/20 flex items-center justify-center cursor-pointer hover:bg-white/10 transition-all overflow-hidden"
              >
                {thumbnail ? <img src={thumbnail} className="w-full h-full object-cover" /> : <span className="text-[10px] font-black text-white/20 uppercase">Click to add thumbnail</span>}
              </div>
              <input type="file" ref={fileRef} className="hidden" accept="image/*" onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  const reader = new FileReader();
                  reader.onloadend = () => setThumbnail(reader.result as string);
                  reader.readAsDataURL(file);
                }
              }} />
            </div>
          </GlassCard>

          <GlassCard className="bg-white/5 border-white/10 p-8">
            <h4 className="font-black text-[10px] uppercase tracking-[0.3em] text-indigo-400 mb-6 flex items-center gap-3">
               <span className="text-xl">🧠</span> Falconx Synthesis
            </h4>
            <p className="text-xs text-white/30 mb-8 leading-relaxed">Gemini will scan your Phase 1 content to generate validated MCQ assessments and follow-up paths.</p>
            <button 
              onClick={handleGenerateQuiz}
              disabled={isGenerating}
              className={`w-full py-5 rounded-2xl font-black uppercase tracking-widest text-[10px] transition-all flex items-center justify-center gap-3 ${
                isGenerating ? 'bg-white/10 text-white/20 cursor-wait' : 'bg-indigo-500 text-white shadow-xl hover:scale-[1.02]'
              }`}
            >
              {isGenerating ? 'Analyzing Ecosystem...' : 'Synthesize Assessment'}
            </button>
          </GlassCard>

          {result && (
            <div className="space-y-4 animate-spring-up">
              <div className="flex items-center justify-between px-2">
                 <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">Synthesis Ready</p>
                 <span className="text-[10px] font-bold text-white/20">{result.mcq.length} Questions</span>
              </div>
              {result.mcq.slice(0, 2).map((q, i) => (
                <GlassCard key={i} className="p-5 border-white/5 bg-white/5">
                  <p className="font-bold text-xs text-white/80 leading-relaxed truncate">{q.question}</p>
                </GlassCard>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
