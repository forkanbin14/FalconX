
import React, { useState, useRef, useEffect } from 'react';
import { UserRole, User, UserProfile } from '../types';
import { GlassCard } from './GlassCard';

interface AuthProps {
  onLogin: (user: User) => void;
}

type AuthStage = 'choice' | 'student-form' | 'teacher-form' | 'admin-form' | 'verification-sent' | 'student-onboarding' | 'teacher-onboarding' | 'face-scan' | 'finger-scan' | 'success';
type AuthMode = 'login' | 'signup';

export const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [role, setRole] = useState<UserRole | null>(null);
  const [stage, setStage] = useState<AuthStage>('choice');
  const [authMode, setAuthMode] = useState<AuthMode>('login');
  
  // Basic Auth State
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  
  // Onboarding State (Shared)
  const [phone, setPhone] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [subject, setSubject] = useState(''); // Target Subject for students
  const [institute, setInstitute] = useState('');
  const [division, setDivision] = useState('Dhaka');

  // Teacher Specific Onboarding
  const [expertiseSubject, setExpertiseSubject] = useState('');
  const [currentInstituteSubject, setCurrentInstituteSubject] = useState('');
  const [mentorshipSubject, setMentorshipSubject] = useState('');
  
  const [adminUser, setAdminUser] = useState('');
  const [adminPass, setAdminPass] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const divisions = ['Dhaka', 'Chittagong', 'Rajshahi', 'Khulna', 'Barishal', 'Sylhet', 'Rangpur', 'Mymensingh'];

  // Helper to generate a code
  const generateUniqueCode = (userRole: UserRole) => {
    const roleCode = userRole === UserRole.STUDENT ? 'STD' : userRole === UserRole.TEACHER ? 'TCH' : 'ADM';
    const hex = Math.random().toString(16).substr(2, 4).toUpperCase();
    return `FX-${roleCode}-${hex}`;
  };

  const startFaceScan = async () => {
    setStage('face-scan');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) videoRef.current.srcObject = stream;
      
      setTimeout(() => {
        stream.getTracks().forEach(t => t.stop());
        setStage('finger-scan');
      }, 3000);
    } catch (err) {
      alert("Camera access required for Biometric verification.");
      setStage('choice');
    }
  };

  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      if (authMode === 'signup') {
        setStage('verification-sent');
      } else {
        // Mock Login
        const dummyCode = role ? generateUniqueCode(role) : 'FX-USR-XXXX';
        if (role === UserRole.TEACHER) {
          startFaceScan();
        } else {
          onLogin({ 
            id: 'student-1', 
            uniqueCode: 'FX-STD-LOGIN-MOCK',
            name: name || 'John Doe', 
            email: email || 'student@falconx.ai', 
            role: UserRole.STUDENT,
            activeStatus: 'online'
          });
        }
      }
    }, 1500);
  };

  const handleStudentOnboardingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setTimeout(() => {
      onLogin({ 
        id: 'student-' + Math.random().toString(36).substr(2, 5), 
        uniqueCode: generateUniqueCode(UserRole.STUDENT),
        name: name, 
        email: email, 
        role: UserRole.STUDENT,
        activeStatus: 'online',
        profile: {
          phone,
          age: parseInt(age),
          gender,
          subject,
          institute,
          division,
          bio: `Passionate student of ${subject}.`
        }
      });
    }, 1500);
  };

  const handleTeacherOnboardingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setTimeout(() => {
      onLogin({ 
        id: 'teacher-' + Math.random().toString(36).substr(2, 5), 
        uniqueCode: generateUniqueCode(UserRole.TEACHER),
        name: name, 
        email: email, 
        role: UserRole.TEACHER,
        activeStatus: 'online',
        profile: {
          phone,
          age: parseInt(age),
          gender,
          expertiseSubject,
          currentInstituteSubject,
          mentorshipSubject,
          institute,
          division,
          bio: `Expert educator in ${expertiseSubject}.`
        },
        isVerified: false 
      });
    }, 1500);
  };

  const handleAdminSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminUser === 'admin' && adminPass === '01641526137@#') {
      onLogin({ id: 'admin-1', uniqueCode: 'FX-ADM-ROOT', name: 'System Admin', email: 'admin@falconx.ai', role: UserRole.ADMIN });
    } else {
      alert("Invalid Admin Credentials");
    }
  };

  const finalizeBiometricAuth = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      if (authMode === 'signup' && role === UserRole.TEACHER) {
        setStage('teacher-onboarding');
      } else {
        onLogin({ 
          id: 'teacher-1', 
          uniqueCode: 'FX-TCH-LOGIN-MOCK',
          name: name || 'Dr. Sarah', 
          email: email || 'teacher@falconx.ai', 
          role: UserRole.TEACHER, 
          activeStatus: 'online',
          isVerified: true 
        });
      }
    }, 2000);
  };

  const confirmVerification = () => {
    if (role === UserRole.STUDENT) {
      setStage('student-onboarding');
    } else if (role === UserRole.TEACHER) {
      startFaceScan();
    }
  };

  const renderChoice = () => (
    <div className="flex flex-col gap-6 w-full max-w-2xl animate-fade-up">
      <div className="text-center mb-8">
        <h1 className="text-6xl font-black text-white tracking-tighter mb-4">Falconx <span className="text-indigo-500 italic">Auth</span></h1>
        <p className="text-white/40 font-medium text-lg">Select your gateway to the Falconx ecosystem.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { r: UserRole.STUDENT, icon: '🎓', label: 'Student', desc: 'Join the journey' },
          { r: UserRole.TEACHER, icon: '👨‍🏫', label: 'Teacher', desc: 'Share knowledge' },
          { r: UserRole.ADMIN, icon: '🛡️', label: 'Admin', desc: 'Secure control' }
        ].map(item => (
          <GlassCard 
            key={item.r}
            onClick={() => {
              setRole(item.r);
              setAuthMode('login'); 
              setStage(item.r === UserRole.STUDENT ? 'student-form' : item.r === UserRole.TEACHER ? 'teacher-form' : 'admin-form');
            }}
            className="group hover:border-indigo-500/50 flex flex-col items-center justify-center p-10 text-center transition-all"
          >
            <span className="text-6xl mb-6 group-hover:scale-110 transition-transform">{item.icon}</span>
            <h3 className="text-xl font-black text-white mb-2">{item.label}</h3>
            <p className="text-[10px] text-white/30 font-bold uppercase tracking-widest">{item.desc}</p>
          </GlassCard>
        ))}
      </div>
    </div>
  );

  const renderAuthForm = (isStudent: boolean) => (
    <GlassCard className="w-full max-w-md p-10 animate-fade-up">
      <button onClick={() => setStage('choice')} className="text-white/20 hover:text-white mb-8 text-xs font-bold uppercase tracking-widest flex items-center gap-2">
        ← Back to roles
      </button>

      <div className="flex bg-white/5 p-1 rounded-2xl border border-white/5 mb-10">
        <button 
          onClick={() => setAuthMode('login')}
          className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${
            authMode === 'login' ? 'bg-indigo-500 text-white shadow-lg' : 'text-white/30 hover:text-white'
          }`}
        >
          Login
        </button>
        <button 
          onClick={() => setAuthMode('signup')}
          className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${
            authMode === 'signup' ? (isStudent ? 'bg-[#2dd4bf] text-black' : 'bg-indigo-500 text-white') + ' shadow-lg' : 'text-white/30 hover:text-white'
          }`}
        >
          Sign Up
        </button>
      </div>

      <div className="mb-10">
        <h2 className="text-3xl font-black text-white tracking-tight mb-2">
          {authMode === 'login' ? 'Welcome Back' : 'Create Account'}
        </h2>
        <p className={`${isStudent ? 'text-[#2dd4bf]' : 'text-indigo-400'} font-bold text-[10px] uppercase tracking-[0.3em]`}>
          {isStudent ? 'Student' : 'Instructor'} {authMode === 'login' ? 'Portal' : 'Onboarding'}
        </p>
      </div>

      <form onSubmit={handleAuthSubmit} className="space-y-6">
        {authMode === 'signup' && (
          <div className="animate-fade-up">
            <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Full Name</label>
            <input 
              value={name} onChange={e => setName(e.target.value)}
              className={`w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-${isStudent ? '[#2dd4bf]' : 'indigo-500'} transition-all font-medium`}
              placeholder="e.g. John Doe"
              required
            />
          </div>
        )}

        <div>
          <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Gmail Address</label>
          <input 
            type="email" value={email} onChange={e => setEmail(e.target.value)}
            className={`w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-${isStudent ? '[#2dd4bf]' : 'indigo-500'} transition-all font-medium`}
            placeholder="name@gmail.com"
            required
          />
        </div>

        <div>
          <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Password</label>
          <input 
            type="password" value={password} onChange={e => setPassword(e.target.value)}
            className={`w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-${isStudent ? '[#2dd4bf]' : 'indigo-500'} transition-all font-medium`}
            placeholder="••••••••"
            required
          />
        </div>

        <button 
          disabled={isProcessing}
          className={`w-full py-5 rounded-2xl text-white font-black uppercase tracking-[0.2em] shadow-xl text-sm transition-all flex items-center justify-center gap-3 ${
            authMode === 'signup' && isStudent ? 'bg-[#2dd4bf] !text-black hover:brightness-110 shadow-[#2dd4bf]/20' : 'btn-gradient'
          }`}
        >
          {isProcessing ? 'Verifying...' : authMode === 'login' ? 'Access Dashboard' : 'Verify Email'}
        </button>
      </form>
    </GlassCard>
  );

  const renderStudentOnboarding = () => (
    <GlassCard className="w-full max-w-2xl p-10 animate-fade-up border-[#2dd4bf]/20">
      <div className="mb-10 text-center">
        <h2 className="text-4xl font-black text-white tracking-tight mb-2">Complete Your <span className="text-[#2dd4bf]">Identity</span></h2>
        <p className="text-white/40 font-medium">Please provide your details to personalize your learning path.</p>
      </div>

      <form onSubmit={handleStudentOnboardingSubmit} className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Phone Number</label>
            <input 
              value={phone} onChange={e => setPhone(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-[#2dd4bf] transition-all font-medium"
              placeholder="+880 1XXX-XXXXXX"
              required
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Age</label>
            <input 
              type="number" value={age} onChange={e => setAge(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-[#2dd4bf] transition-all font-medium"
              placeholder="e.g. 21"
              required
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Gender</label>
            <select 
              value={gender} onChange={e => setGender(e.target.value as any)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-[#2dd4bf] transition-all font-medium appearance-none"
              required
            >
              <option value="Male" className="bg-slate-900">Male</option>
              <option value="Female" className="bg-slate-900">Female</option>
              <option value="Other" className="bg-slate-900">Other</option>
            </select>
          </div>
          <div>
            <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Target Subject</label>
            <input 
              value={subject} onChange={e => setSubject(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-[#2dd4bf] transition-all font-medium"
              placeholder="e.g. Web Development"
              required
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Institute</label>
            <input 
              value={institute} onChange={e => setInstitute(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-[#2dd4bf] transition-all font-medium"
              placeholder="University or College Name"
              required
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Division</label>
            <select 
              value={division} onChange={e => setDivision(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-[#2dd4bf] transition-all font-medium appearance-none"
              required
            >
              {divisions.map(d => <option key={d} value={d} className="bg-slate-900">{d}</option>)}
            </select>
          </div>
        </div>

        <button 
          disabled={isProcessing}
          className="w-full py-5 rounded-2xl bg-[#2dd4bf] text-black font-black uppercase tracking-[0.2em] shadow-xl shadow-[#2dd4bf]/20 text-sm transition-all flex items-center justify-center gap-3 hover:scale-[1.02]"
        >
          {isProcessing ? 'Finalizing Profile...' : 'Complete Signup'}
        </button>
      </form>
    </GlassCard>
  );

  const renderTeacherOnboarding = () => (
    <GlassCard className="w-full max-w-2xl p-10 animate-fade-up border-indigo-500/20">
      <div className="mb-10 text-center">
        <h2 className="text-4xl font-black text-white tracking-tight mb-2">Instructor <span className="text-indigo-500">Expert Profile</span></h2>
        <p className="text-white/40 font-medium">Define your educational background and expertise.</p>
      </div>

      <form onSubmit={handleTeacherOnboardingSubmit} className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Phone Number</label>
            <input 
              value={phone} onChange={e => setPhone(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-indigo-500 transition-all font-medium"
              placeholder="+880 1XXX-XXXXXX"
              required
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Age</label>
            <input 
              type="number" value={age} onChange={e => setAge(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-indigo-500 transition-all font-medium"
              placeholder="e.g. 35"
              required
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Gender</label>
            <select 
              value={gender} onChange={e => setGender(e.target.value as any)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-indigo-500 transition-all font-medium appearance-none"
              required
            >
              <option value="Male" className="bg-slate-900">Male</option>
              <option value="Female" className="bg-slate-900">Female</option>
              <option value="Other" className="bg-slate-900">Other</option>
            </select>
          </div>
          <div>
            <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Expertise Subject</label>
            <input 
              value={expertiseSubject} onChange={e => setExpertiseSubject(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-indigo-500 transition-all font-medium"
              placeholder="e.g. Quantum Computing"
              required
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Current Subject in Institute</label>
            <input 
              value={currentInstituteSubject} onChange={e => setCurrentInstituteSubject(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-indigo-500 transition-all font-medium"
              placeholder="e.g. Introduction to Computer Science"
              required
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Institute / University</label>
            <input 
              value={institute} onChange={e => setInstitute(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-indigo-500 transition-all font-medium"
              placeholder="University or Organization Name"
              required
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Subject You Want to Mentor</label>
            <input 
              value={mentorshipSubject} onChange={e => setMentorshipSubject(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-indigo-500 transition-all font-medium"
              placeholder="e.g. Full-stack Web Development"
              required
            />
          </div>
        </div>

        <button 
          disabled={isProcessing}
          className="w-full py-5 rounded-2xl bg-indigo-500 text-white font-black uppercase tracking-[0.2em] shadow-xl shadow-indigo-500/20 text-sm transition-all flex items-center justify-center gap-3 hover:scale-[1.02]"
        >
          {isProcessing ? 'Finalizing Profile...' : 'Complete Teacher Signup'}
        </button>
      </form>
    </GlassCard>
  );

  const renderAdminForm = () => (
    <GlassCard className="w-full max-w-md p-10 animate-fade-up">
      <button onClick={() => setStage('choice')} className="text-white/20 hover:text-white mb-8 text-xs font-bold uppercase tracking-widest flex items-center gap-2">
        ← Back to roles
      </button>
      <div className="mb-10 text-center">
        <h2 className="text-3xl font-black text-white tracking-tight mb-2">Restricted Access</h2>
        <p className="text-red-400 font-bold text-[10px] uppercase tracking-[0.3em]">Falcon Control Center</p>
      </div>
      <form onSubmit={handleAdminSubmit} className="space-y-6">
        <div>
          <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Admin Username</label>
          <input 
            value={adminUser} onChange={e => setAdminUser(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-red-500 transition-all font-medium"
            placeholder="System Identifier"
          />
        </div>
        <div>
          <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3 ml-1">Secret Key</label>
          <input 
            type="password" value={adminPass} onChange={e => setAdminPass(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-red-500 transition-all font-medium"
            placeholder="••••••••"
          />
        </div>
        <button 
          disabled={isProcessing}
          className="w-full bg-red-600 hover:bg-red-500 py-5 rounded-2xl text-white font-black uppercase tracking-[0.2em] shadow-xl text-sm transition-all flex items-center justify-center gap-3"
        >
          {isProcessing ? 'Authorizing...' : 'Enter Secure Mode'}
        </button>
      </form>
    </GlassCard>
  );

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-[#0f172a] relative overflow-hidden">
      <div className="absolute top-1/4 -right-48 w-96 h-96 bg-indigo-600/20 blur-[150px] rounded-full pointer-events-none"></div>
      <div className="absolute bottom-1/4 -left-48 w-96 h-96 bg-purple-600/20 blur-[150px] rounded-full pointer-events-none"></div>

      {stage === 'choice' && renderChoice()}
      {stage === 'student-form' && renderAuthForm(true)}
      {stage === 'teacher-form' && renderAuthForm(false)}
      {stage === 'admin-form' && renderAdminForm()}
      
      {stage === 'student-onboarding' && renderStudentOnboarding()}
      {stage === 'teacher-onboarding' && renderTeacherOnboarding()}

      {stage === 'verification-sent' && (
        <GlassCard className="w-full max-w-md p-12 text-center animate-fade-up">
          <div className="w-20 h-20 bg-indigo-500/20 rounded-3xl flex items-center justify-center mx-auto mb-8 animate-bounce">
             <span className="text-4xl">📧</span>
          </div>
          <h2 className="text-3xl font-black text-white mb-4">Check Your Inbox</h2>
          <p className="text-white/40 mb-10 leading-relaxed font-medium">We've sent a secure verification link to <span className="text-indigo-400">{email}</span>. Please click it to proceed.</p>
          <button onClick={confirmVerification} className="w-full btn-gradient py-4 rounded-2xl text-white font-black uppercase tracking-widest">I've Verified My Email</button>
        </GlassCard>
      )}

      {stage === 'face-scan' && (
        <GlassCard className="w-full max-w-lg p-0 overflow-hidden animate-fade-up border-indigo-500/30">
          <div className="relative aspect-square bg-black flex items-center justify-center">
            <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover opacity-80" />
            <div className="absolute inset-0 border-[20px] border-black/40"></div>
            <div className="absolute inset-0 overflow-hidden">
               <div className="w-full h-1 bg-indigo-500/80 shadow-[0_0_15px_rgba(99,102,241,1)] animate-[scan_2s_ease-in-out_infinite]"></div>
            </div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 border-2 border-indigo-500/50 rounded-[4rem] flex items-center justify-center">
               <div className="text-indigo-400 font-black uppercase text-[10px] tracking-[0.4em] bg-black/40 backdrop-blur px-4 py-2 rounded-lg">AI Face Recognition</div>
            </div>
          </div>
          <div className="p-10 text-center">
             <h3 className="text-2xl font-black text-white mb-2">Analyzing Features...</h3>
             <p className="text-white/30 text-sm font-medium italic">Falconx Neural Engine is verifying your identity.</p>
          </div>
          <style>{`
            @keyframes scan {
              0% { transform: translateY(0); }
              100% { transform: translateY(400px); }
            }
          `}</style>
        </GlassCard>
      )}

      {stage === 'finger-scan' && (
        <GlassCard className="w-full max-w-md p-12 text-center animate-fade-up">
           <div className="relative w-32 h-32 mx-auto mb-10 group cursor-pointer" onClick={finalizeBiometricAuth}>
              <div className="absolute inset-0 bg-indigo-500/20 blur-3xl rounded-full group-hover:bg-indigo-500/40 transition-all"></div>
              <div className="relative w-full h-full glass rounded-[2.5rem] border-indigo-500/40 flex items-center justify-center">
                 <span className="text-6xl group-hover:scale-110 transition-transform">👆</span>
                 <div className="absolute inset-2 border-2 border-indigo-500/20 rounded-[2rem] animate-ping"></div>
              </div>
           </div>
           <h3 className="text-2xl font-black text-white mb-4">Biometric Verification</h3>
           <p className="text-white/40 mb-10 text-sm font-medium">Place your finger on the virtual sensor or click to finalize instructor authentication.</p>
           {isProcessing ? (
             <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
               <div className="h-full bg-indigo-500 animate-[loading_2s_linear_infinite]"></div>
             </div>
           ) : (
             <p className="text-indigo-400 font-black uppercase text-[10px] tracking-widest animate-pulse">Waiting for touch...</p>
           )}
           <style>{`
            @keyframes loading { 0% { width: 0; } 100% { width: 100%; } }
           `}</style>
        </GlassCard>
      )}
    </div>
  );
};
