
import React from 'react';
import { UserRole } from '../types';
import { FalconxLogo } from './FalconxLogo';

interface SidebarProps {
  role: UserRole;
  currentView: string;
  setView: (view: string) => void;
  isOpen: boolean;
  onClose: () => void;
  onLogout?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ role, currentView, setView, isOpen, onClose, onLogout }) => {
  const menuItems = {
    [UserRole.STUDENT]: [
      { id: 'dashboard', label: 'Dashboard', icon: '🏠' },
      { id: 'browse', label: 'Browse Courses', icon: '🔍' },
      { id: 'profile', label: 'My Profile', icon: '👤' },
      { id: 'live-classes', label: 'Live Classes', icon: '🔴' },
      { id: 'recorded-classes', label: 'Masterclass Vault', icon: '📼' },
      { id: 'live-exams', label: 'Live Exams', icon: '📝' },
      { id: 'inbox', label: 'Inbox', icon: '📩' },
      { id: 'tutor', label: 'AI Tutor', icon: '🤖' },
    ],
    [UserRole.TEACHER]: [
      { id: 'teacher-dashboard', label: 'My Modules', icon: '📚' },
      { id: 'profile', label: 'My Profile', icon: '👤' },
      { id: 'create-course', label: 'Create Course', icon: '➕' },
      { id: 'live-classes', label: 'Live Classes', icon: '🎥' },
      { id: 'live-exams', label: 'Manage Exams', icon: '📝' },
      { id: 'admin-chat', label: 'Admin Support', icon: '🎧' },
      { id: 'student-messages', label: 'Students', icon: '📩' },
    ],
    [UserRole.ADMIN]: [
      { id: 'admin-dashboard', label: 'Admin Hub', icon: '🛡️' },
      { id: 'live-classes', label: 'Monitor Live', icon: '📺' },
      { id: 'approvals', label: 'Approvals', icon: '✅' },
      { id: 'admin-messages', label: 'Messages', icon: '📩' },
      { id: 'users', label: 'Users', icon: '👥' },
    ],
  };

  return (
    <>
      {/* Mobile Overlay */}
      <div 
        className={`fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      />

      <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-72 h-full glass border-r border-white/10 p-8 flex flex-col gap-10 transition-transform duration-300 cubic-bezier(0.4, 0, 0.2, 1) ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="flex flex-col items-center">
          <div className="w-48 mb-4 hover:scale-105 transition-transform duration-500">
            <FalconxLogo />
          </div>
          <button onClick={onClose} className="lg:hidden absolute top-8 right-8 p-2 text-white/40 hover:text-white">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
        </div>

        <nav className="flex-1 flex flex-col gap-2 overflow-y-auto custom-scrollbar pr-2">
          {menuItems[role].map((item) => (
            <button
              key={item.id}
              onClick={() => { setView(item.id); onClose(); }}
              className={`flex items-center gap-4 px-5 py-4 rounded-2xl transition-all duration-300 group ${
                currentView === item.id 
                  ? 'bg-indigo-500 text-white shadow-xl shadow-indigo-500/20' 
                  : 'text-white/40 hover:bg-white/5 hover:text-white'
              }`}
            >
              <span className={`text-xl transition-transform group-hover:scale-110 ${currentView === item.id ? 'scale-110' : ''}`}>{item.icon}</span>
              <span className="font-semibold text-sm tracking-wide">{item.label}</span>
              {currentView === item.id && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-white animate-pulse" />}
            </button>
          ))}
        </nav>

        <div className="bg-white/5 p-5 rounded-[1.5rem] border border-white/5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full border-2 border-indigo-500/30 p-0.5">
               <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${role}`} className="rounded-full bg-indigo-500/10" />
            </div>
            <div>
              <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest">Active Role</p>
              <p className="text-sm font-bold text-white capitalize">{role.toLowerCase()}</p>
            </div>
          </div>
          <button 
            onClick={onLogout}
            className="w-full py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-bold text-white/60 hover:text-white transition-all"
          >
            Sign Out
          </button>
        </div>
      </aside>
    </>
  );
};
