
import React, { useState, useRef, useEffect } from 'react';
import { Notification, ActiveStatus } from '../types';
import { GlassCard } from './GlassCard';

interface NavbarProps {
  onMenuClick: () => void;
  userName: string;
  notifications: Notification[];
  onMarkRead: () => void;
  currentStatus: ActiveStatus;
  onStatusChange: (status: ActiveStatus) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  onMenuClick, 
  userName, 
  notifications, 
  onMarkRead,
  currentStatus,
  onStatusChange
}) => {
  const [showNotifs, setShowNotifs] = useState(false);
  const [showStatusMenu, setShowStatusMenu] = useState(false);
  const unreadCount = notifications.filter(n => !n.isRead).length;
  const dropdownRef = useRef<HTMLDivElement>(null);
  const statusRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowNotifs(false);
      }
      if (statusRef.current && !statusRef.current.contains(event.target as Node)) {
        setShowStatusMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleToggleNotifs = () => {
    if (!showNotifs && unreadCount > 0) onMarkRead();
    setShowNotifs(!showNotifs);
  };

  const getStatusColor = (status: ActiveStatus) => {
    switch (status) {
      case 'online': return 'bg-emerald-500';
      case 'away': return 'bg-amber-500';
      case 'busy': return 'bg-red-500';
      case 'offline': return 'bg-slate-500';
      default: return 'bg-slate-500';
    }
  };

  return (
    <nav className="sticky top-0 z-30 h-20 w-full nav-blur px-6 lg:px-12 flex items-center justify-between">
      <div className="flex items-center gap-4">
        <button 
          onClick={onMenuClick}
          className="lg:hidden p-2 bg-white/5 rounded-xl text-white hover:bg-white/10 transition-colors"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
        </button>
        <div className="hidden md:flex items-center gap-3 bg-white/5 px-4 py-2.5 rounded-2xl border border-white/5 w-64 lg:w-96 focus-within:border-indigo-500/50 transition-all">
          <svg className="w-4 h-4 text-white/30" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
          <input 
            type="text" 
            placeholder="Search ecosystem..." 
            className="bg-transparent border-none text-sm text-white focus:outline-none w-full placeholder:text-white/20"
          />
        </div>
      </div>

      <div className="flex items-center gap-4 lg:gap-6">
        <div className="relative" ref={dropdownRef}>
          <button 
            onClick={handleToggleNotifs}
            className={`relative p-2.5 bg-white/5 rounded-xl text-white hover:bg-white/10 transition-all ${unreadCount > 0 ? 'ring-2 ring-indigo-500/50' : ''}`}
          >
            <svg className={`w-5 h-5 ${unreadCount > 0 ? 'animate-[swing_2s_ease-in-out_infinite]' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-4 w-4 bg-indigo-500 items-center justify-center text-[8px] font-black">{unreadCount}</span>
              </span>
            )}
          </button>

          {showNotifs && (
            <div className="absolute right-0 mt-4 w-80 md:w-96 glass-card rounded-3xl overflow-hidden shadow-2xl animate-fade-up z-50">
              <div className="p-5 border-b border-white/5 bg-indigo-500/10 flex items-center justify-between">
                <h4 className="font-black text-xs uppercase tracking-widest text-indigo-400">Activity Pulse</h4>
                <span className="text-[10px] bg-white/5 px-2 py-1 rounded-md text-white/40 font-bold">{notifications.length} Total</span>
              </div>
              <div className="max-h-[450px] overflow-y-auto custom-scrollbar">
                {notifications.length === 0 ? (
                  <div className="p-12 text-center opacity-20 flex flex-col items-center gap-4">
                    <span className="text-5xl">🔔</span>
                    <p className="text-xs font-black uppercase tracking-widest leading-relaxed">System Quiet<br/>No active alerts</p>
                  </div>
                ) : (
                  notifications.map((n) => (
                    <div 
                      key={n.id} 
                      className={`p-5 border-b border-white/5 flex gap-5 transition-all hover:bg-white/5 ${!n.isRead ? 'bg-indigo-500/5' : ''}`}
                    >
                      <div className={`w-12 h-12 shrink-0 rounded-2xl flex items-center justify-center text-xl shadow-inner ${
                        n.type === 'success' ? 'bg-emerald-500/20 text-emerald-400' :
                        n.type === 'error' ? 'bg-red-500/20 text-red-400' :
                        n.type === 'warning' ? 'bg-amber-500/20 text-amber-400' :
                        'bg-indigo-500/20 text-indigo-400'
                      }`}>
                        {n.title.includes('Payment') || n.title.includes('Payout') ? '💸' : 
                         n.title.includes('Message') ? '📩' : 
                         n.title.includes('Identity') || n.title.includes('Verified') ? '👤' : 'ℹ️'}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="font-black text-sm text-white mb-1.5 tracking-tight">{n.title}</p>
                        <p className="text-xs text-white/50 leading-relaxed line-clamp-2 font-medium">{n.message}</p>
                        <p className="text-[9px] font-black text-white/10 mt-3 uppercase tracking-widest">{n.timestamp}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        <div className="relative" ref={statusRef}>
          <div 
            onClick={() => setShowStatusMenu(!showStatusMenu)}
            className="hidden sm:flex items-center gap-3 cursor-pointer hover:bg-white/5 px-3 py-1.5 rounded-2xl transition-all border border-transparent hover:border-white/5"
          >
            <div className="text-right">
              <p className="text-sm font-black text-white leading-tight">{userName}</p>
              <div className="flex items-center justify-end gap-2 mt-0.5">
                <span className={`w-1.5 h-1.5 rounded-full ${getStatusColor(currentStatus)} shadow-sm`}></span>
                <p className="text-[9px] text-white/30 font-black uppercase tracking-wider">{currentStatus}</p>
              </div>
            </div>
            <div className="relative">
              <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center font-black text-white shadow-lg border border-white/10">
                {userName.charAt(0)}
              </div>
              <div className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 ${getStatusColor(currentStatus)} border-2 border-[#0f172a] rounded-full`}></div>
            </div>
          </div>

          {showStatusMenu && (
            <div className="absolute right-0 mt-4 w-52 glass-card rounded-2xl overflow-hidden shadow-2xl animate-fade-up z-50">
              <div className="p-3 border-b border-white/5 bg-white/5">
                <p className="text-[9px] font-black text-white/30 uppercase tracking-widest">Presence Node</p>
              </div>
              <div className="p-2 space-y-1">
                {(['online', 'away', 'busy', 'offline'] as ActiveStatus[]).map((status) => (
                  <button
                    key={status}
                    onClick={() => {
                      onStatusChange(status);
                      setShowStatusMenu(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all ${
                      currentStatus === status ? 'bg-indigo-500/20 text-indigo-400' : 'hover:bg-white/5 text-white/60 hover:text-white'
                    }`}
                  >
                    <span className={`w-2 h-2 rounded-full ${getStatusColor(status)}`}></span>
                    <span className="text-xs font-black capitalize tracking-tight">{status}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
      <style>{`
        @keyframes swing {
          0% { transform: rotate(0); }
          10% { transform: rotate(10deg); }
          30% { transform: rotate(-10deg); }
          50% { transform: rotate(5deg); }
          70% { transform: rotate(-5deg); }
          100% { transform: rotate(0); }
        }
      `}</style>
    </nav>
  );
};
