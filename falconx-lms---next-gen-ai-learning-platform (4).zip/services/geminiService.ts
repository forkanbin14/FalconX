
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { QuizGenerationResult, Difficulty } from "../types";

// Always use named parameter for apiKey and use process.env.API_KEY directly
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const geminiService = {
  // Quiz generation is a complex reasoning task, using gemini-3-pro-preview
  async generateQuiz(
    topic: string, 
    content: string, 
    difficulty: Difficulty
  ): Promise<QuizGenerationResult> {
    const prompt = `Generate a quiz based on the following details:
    Topic: ${topic}
    Difficulty: ${difficulty}
    Content: ${content}

    You must return a JSON object with:
    1. "mcq": array of 5 objects with "question", "options" (4 strings), "answer" (string matching one option), and "explanation".
    2. "short": array of 3 descriptive or short-answer questions.
    3. "suggestions": a string with advice for the student based on this lesson.`;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              mcq: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    question: { type: Type.STRING },
                    options: { 
                      type: Type.ARRAY, 
                      items: { type: Type.STRING }
                    },
                    answer: { type: Type.STRING },
                    explanation: { type: Type.STRING }
                  },
                  propertyOrdering: ["question", "options", "answer", "explanation"]
                }
              },
              short: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              suggestions: { type: Type.STRING }
            },
            propertyOrdering: ["mcq", "short", "suggestions"]
          }
        }
      });

      const jsonStr = response.text.trim();
      return JSON.parse(jsonStr);
    } catch (error) {
      console.error("Error generating quiz:", error);
      throw error;
    }
  },

  // AI Tutor Falconx - Supports text and multimodal parts (attachments)
  async getAiTutorResponse(history: any[], message: any, context: string) {
    const chat = ai.chats.create({
      model: 'gemini-3-pro-preview',
      config: {
        systemInstruction: `You are Falconx, the elite AI Intelligent Tutor of Falconx LMS.
        
        Rules:
        1. Contextual Knowledge: Answer ONLY using the provided course content or the specific educational topic. Context: ${context}
        2. Auto Language Detection: Analyze the user's input language. If they speak Bangla, respond in Bangla. If they speak English, respond in English. If they use a mix (Banglish), respond in a similar natural mix.
        3. Examples: Always provide concrete, real-world examples or industry-standard analogies to explain complex concepts.
        4. Pedagogy: You MUST end every single response with a thought-provoking follow-up question that bridges the current explanation to a new sub-topic or tests the student's intuition.
        5. Multimodal: If the user provides an image or file, analyze it in the context of the course and help them understand it.
        
        Tone: Encouraging, professional, and sophisticated. Adapt your complexity to the user's tone.`,
      },
      history: history
    });

    try {
      const result = await chat.sendMessage({ message });
      return result.text;
    } catch (error) {
      console.error("AI Tutor Error:", error);
      return "Dukkito! Amar processing e ektu shomoshya hochche. Please ask again!";
    }
  },

  // Text to Speech for Falconx responses
  async textToSpeech(text: string, voiceName: string = 'Kore'): Promise<string | undefined> {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Say clearly: ${text}` }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName },
            },
          },
        },
      });
      return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    } catch (error) {
      console.error("TTS Error:", error);
      return undefined;
    }
  },

  // Performance feedback is a basic task
  async analyzeResult(score: number, total: number, quizTitle: string) {
    const prompt = `Analyze a student's performance on a quiz titled "${quizTitle}". 
    The student scored ${score} out of ${total}. 
    Provide a brief (2-3 sentences), personalized feedback as Falconx AI. Use a mix of Bangla and English.`;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt
      });
      return response.text;
    } catch (error) {
      return "Keep up the hard work! Consistency is the key to mastery.";
    }
  }
};
