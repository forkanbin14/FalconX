
import { User, UserRole, Course, RecordedClass } from '../types';

export const INITIAL_CATEGORIES = [
  'Web Development',
  'Mobile Development',
  'AI & Machine Learning',
  'UI/UX Design',
  'Data Science',
  'Business',
  'Cybersecurity'
];

export const MOCK_RECORDED_CLASSES: RecordedClass[] = [
  {
    id: 'rec-1',
    title: 'Modern Web Architecture: Part 1',
    courseId: 'c1',
    instructorName: 'Dr. Sarah Teacher',
    videoUrl: '#',
    slidesUrl: '#',
    duration: '1h 24m',
    date: '2023-12-01',
    thumbnail: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&q=80&w=600'
  },
  {
    id: 'rec-2',
    title: 'UI Design Principles & Glassmorphism',
    courseId: 'c2',
    instructorName: 'Dr. Sarah Teacher',
    videoUrl: '#',
    slidesUrl: '#',
    duration: '45m',
    date: '2023-11-28',
    thumbnail: 'https://images.unsplash.com/photo-1558655146-d09347e92766?auto=format&fit=crop&q=80&w=600'
  }
];

export const MOCK_USERS: User[] = [
  { 
    id: 'u1', 
    uniqueCode: 'FX-STD-4821',
    name: 'John Student', 
    email: 'student@falconx.ai', 
    role: UserRole.STUDENT, 
    avatar: 'https://picsum.photos/100/100?random=1', 
    activeStatus: 'online',
    isVerified: false,
    walletBalance: 0,
    profile: {
      bio: 'Lifelong learner interested in full-stack development and AI.',
      currentCity: 'Dhaka',
      division: 'Dhaka',
      educationLevel: 'Undergrad',
      institute: 'University of Dhaka'
    }
  },
  { 
    id: 'u2', 
    uniqueCode: 'FX-TCH-9912',
    name: 'Dr. Sarah Teacher', 
    email: 'teacher@falconx.ai', 
    role: UserRole.TEACHER, 
    avatar: 'https://picsum.photos/100/100?random=2', 
    activeStatus: 'online',
    isVerified: true,
    walletBalance: 12500, // Initial liquidity
    profile: {
      bio: 'PhD in Computer Science, specializing in Distributed Systems and React Performance.',
      currentCity: 'Chittagong',
      division: 'Chittagong',
      institute: 'CUET',
      experience: '12 Years',
      subject: 'Modern Web Architecture'
    }
  },
  { 
    id: 'u3', 
    uniqueCode: 'FX-ADM-0001',
    name: 'Admin One', 
    email: 'admin@falconx.ai', 
    role: UserRole.ADMIN, 
    avatar: 'https://picsum.photos/100/100?random=3', 
    activeStatus: 'online',
    isVerified: true
  },
];

export const INITIAL_COURSES: Course[] = [
  {
    id: 'c1',
    title: 'Advanced React Architecture',
    description: 'Master the core concepts of building scalable React applications with modern design patterns.',
    thumbnail: 'https://picsum.photos/600/400?random=10',
    instructorId: 'u2',
    price: 5500,
    isApproved: true,
    // Fix: Added missing status property required by Course type
    status: 'published',
    category: 'Web Development',
    lessons: [
      { 
        id: 'l1', 
        title: 'Introduction to Atomic Design', 
        content: 'Atomic design is a methodology for creating design systems...',
        materials: [
          { id: 'm1', title: 'Atomic Design Cheatsheet', url: '#', type: 'pdf' },
          { id: 'm2', title: 'Component Library Source', url: '#', type: 'zip' }
        ]
      },
      { 
        id: 'l2', 
        title: 'State Management with Jotai', 
        content: 'Jotai takes an atomic approach to global React state management...',
        materials: [
          { id: 'm3', title: 'State Flow Diagram', url: '#', type: 'image' }
        ]
      }
    ],
    quizzes: []
  },
  {
    id: 'c2',
    title: 'Modern UI with Tailwind',
    description: 'Learn how to build stunning, responsive user interfaces using the power of Tailwind CSS.',
    thumbnail: 'https://picsum.photos/600/400?random=11',
    instructorId: 'u2',
    price: 3200,
    isApproved: true,
    // Fix: Added missing status property required by Course type
    status: 'published',
    category: 'UI/UX Design',
    lessons: [
      { 
        id: 'l3', 
        title: 'Utility-First Fundamentals', 
        content: 'Tailwind is a utility-first CSS framework...',
        materials: [
          { id: 'm4', title: 'Tailwind UI Kit', url: '#', type: 'link' }
        ]
      }
    ],
    quizzes: []
  }
];
