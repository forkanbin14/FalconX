
import mongoose, { Schema, Document, model, models } from 'mongoose';

/**
 * User Schema
 * Handles authentication, role-based access, and course tracking.
 */
const UserSchema = new Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true }, // Hashed password
  role: { 
    type: String, 
    enum: ['STUDENT', 'TEACHER', 'ADMIN'], 
    default: 'STUDENT' 
  },
  avatar: { type: String },
  enrolledCourses: [{ type: Schema.Types.ObjectId, ref: 'Course' }],
  createdAt: { type: Date, default: Date.now },
});

/**
 * Lesson Schema (Sub-document for Course)
 */
const LessonSchema = new Schema({
  title: { type: String, required: true },
  content: { type: String },
  videoUrl: { type: String },
  pdfUrl: { type: String },
});

/**
 * Course Schema
 * Core entity for educational content.
 */
const CourseSchema = new Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  thumbnail: { type: String },
  teacher: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  lessons: [LessonSchema],
  price: { type: Number, default: 0 },
  isApproved: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
});

/**
 * Quiz Schema
 * Linked to courses for assessment.
 */
const QuizSchema = new Schema({
  courseId: { type: Schema.Types.ObjectId, ref: 'Course', required: true },
  title: { type: String, required: true },
  questions: [{
    question: { type: String, required: true },
    options: [{ type: String, required: true }],
    correctAnswer: { type: String, required: true }, // The string value of the correct option
    explanation: { type: String }
  }],
  difficulty: { 
    type: String, 
    enum: ['Basic', 'Intermediate', 'Advanced'], 
    default: 'Intermediate' 
  },
  createdAt: { type: Date, default: Date.now },
});

// Export Models
// Note: In Next.js, we check if the model already exists to prevent re-compilation errors during hot reloads.
export const User = models.User || model('User', UserSchema);
export const Course = models.Course || model('Course', CourseSchema);
export const Quiz = models.Quiz || model('Quiz', QuizSchema);
